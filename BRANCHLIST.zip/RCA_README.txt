 RCA_README.txt

## Zip SetUp File:  Download-RCA_PDF.zip

Contains

	1. PDFSplitter.exe
        2. RenameRCA.exe
        3. RCA_README.txt
        4. iTextSharp.dll
        5. LOGS Folder

## Features

- PDFSplitter.exe and RenameRCA.exe - The Application for RCA
 

## Steps for Set Up

- Extract All Download-RCA_PDF.zip
- Rename Download-CRS to RCA_SPLITTER_PROD 
- Place it on Desktop 
- Create Shortcut for CRS_WEB.exe

## Dependencies
 

## Getting Started
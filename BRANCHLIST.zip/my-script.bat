@echo off

REM Move all PDF files from Downloads to Documents\PDFs folder
move "C:\Users\solomongs\Downloads\*.zip" "C:\CTS_WEB_AppFolder\"
REM Move all other files (if needed)
move "C:\Users\solomongs\Downloads\*.*" "C:\CTS_WEB_AppFolder\"
pause
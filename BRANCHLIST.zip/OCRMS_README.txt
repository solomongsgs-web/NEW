 OCRMS_README.txt

## Zip SetUp File:  Download-OCRMS.zip

Contains

	1. OCRMS.exe
        2. OCRMS_README.txt
        3. CONFIG.txt
	4. IonicZip.dll
	5. clsIonicZip.dll
        6. LOGS Folder

## Features

- OCRMS.exe - The Application for OCRMS Module
 

## Steps for Set Up

- Extract All Download-OCRMS.zip
- Rename Download-CRS to OCRMS_PROD 
- Place it on Desktop 
- Create Shortcut for OCRMS.exe

## Dependencies
 
- CONFIG.txt 
- IonicZip.dll
- clsIonicZip.dll

## Getting Started
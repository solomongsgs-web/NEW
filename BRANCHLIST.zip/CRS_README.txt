 CRS_README.txt

## Zip SetUp File:  Download-CRS.zip

Contains

	1. CRS_WEB.exe
        2. CRS_README.txt
        3. LOGS Folder

## Features

- CRS_WEB.exe - The Application for CRS
 

## Steps for Set Up

- Extract All Download-CRS.zip
- Rename Download-CRS to CRS_PROD 
- Place it on Desktop 
- Create Shortcut for CRS_WEB.exe

## Dependencies
 

## Getting Started
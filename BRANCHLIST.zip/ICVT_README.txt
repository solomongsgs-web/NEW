 ICVT_README.txt

## Zip SetUp File:  Download-ICVT.zip

Contains

	1. ICVT.exe
        2. ICVT_README.txt
        3. CONFIG.txt
	4. IonicZip.dll
        5. LOGS Folder

## Features

- ICVT.exe - The Application for ICVT Module
 

## Steps for Set Up

- Extract All Download-ICVT.zip
- Rename Download-CRS to ICVT_PROD 
- Place it on Desktop 
- Create Shortcut for ICVT.exe

## Dependencies
 
- CONFIG.txt 
- IonicZip.dll

## Getting Started
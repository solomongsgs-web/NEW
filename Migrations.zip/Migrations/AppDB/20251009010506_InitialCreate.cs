﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CTS_WEB.Migrations.AppDB
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Biller",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BillerCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BillerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AcctNo1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AcctNo2 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Biller", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Configs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DBName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DBUID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DBPass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DBPKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DBIV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DLFolder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ULFolder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPIP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPPath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPUID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPPass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SFTPIV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTIP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTPath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTUID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTPass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTPKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARMFTPIV = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Configs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Settings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HostIP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Port = table.Column<int>(type: "int", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PIV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FingerPrint = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RemoteMFTFilePath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RemoteMFTSendPath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DLFolder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UPFolder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OutputPath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARHostIP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARUserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARPassword = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARPKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARPIV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UARSendFolder = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Settings", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Biller");

            migrationBuilder.DropTable(
                name: "Configs");

            migrationBuilder.DropTable(
                name: "Settings");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CTS_WEB.Migrations.AppDB
{
    /// <inheritdoc />
    public partial class AddUserPass1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Branches_SI",
                columns: table => new
                {
                    SEQ = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    BRCODE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BRACRO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REGION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BRNAME = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NEWBRSTN = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OLDBRSTN = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AREA = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OLDNAME = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ORDERING = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "UserPass",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmpId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PASSWORD = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PKEY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PIV = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserPass", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Branches_SI");

            migrationBuilder.DropTable(
                name: "UserPass");
        }
    }
}

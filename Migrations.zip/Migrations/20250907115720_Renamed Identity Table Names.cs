﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CTS_WEB.Migrations
{
    /// <inheritdoc />
    public partial class RenamedIdentityTableNames : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

﻿using WinSCP;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using EnumerationOptions = WinSCP.EnumerationOptions;

namespace CTS_WEB.Services
{
    public class WinScpService
    {
        private readonly IConfiguration _configuration;

        public WinScpService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<RemoteFileInfo> GetFileList(string remotePath)
        {
            var sessionOptions = new WinSCP.SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = _configuration["Sftp:Host"],
                UserName = _configuration["Sftp:Username"],
                Password = _configuration["Sftp:Password"],
                SshHostKeyFingerprint = _configuration["Sftp:SshHostKeyFingerprint"]
            };

            using (var session = new Session())
            {
                session.Open(sessionOptions);
                var remoteFiles = session.EnumerateRemoteFiles(remotePath, null, EnumerationOptions.AllDirectories)
                    .Where(fileInfo => !fileInfo.IsDirectory)
                    .Select(fileInfo => new RemoteFileInfo
                    {
                        FileName = fileInfo.Name,
                        FullPath = fileInfo.FullName,
                        IsSelected = false // Initial state
                    })
                    .ToList();

                session.Close();
                return remoteFiles;
            }
        }

        public void DownloadFile(string remoteFileName, string localPath)
        {
            //var sftpSettings = _configuration.GetSection("SftpSettings");

            var sessionOptions = new WinSCP.SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = _configuration["Sftp:Host"],
                UserName = _configuration["Sftp:Username"],
                Password = _configuration["Sftp:Password"],
                SshHostKeyFingerprint = _configuration["Sftp:SshHostKeyFingerprint"]
                //_configuration["Sftp:RemoteFilePath"]
            };
            using (var session = new Session())
            {
                try
                {
                    // Connect to the SFTP server
                    session.Open(sessionOptions);

                    // Define remote and local paths
                    string remoteFilePath = Path.Combine(_configuration["Sftp:RemoteFilePath"], remoteFileName).Replace("\\", "/");
                    string localFilePath = Path.Combine(localPath, remoteFileName);

                    // Download the file
                    session.GetFiles(remoteFilePath, localFilePath);

                    session.Close();
                }
                catch (Exception ex)
                {
                    // Log the exception for troubleshooting
                    throw new Exception($"SFTP download failed: {ex.Message}");
                }
            }
        }

    }
    public class RemoteFileInfo
    {
        public string FileName { get; set; }
        public string FullPath { get; set; }
        public bool IsSelected { get; set; }
    }

}

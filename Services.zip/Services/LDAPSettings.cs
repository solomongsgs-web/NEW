﻿namespace CTS_WEB.Services
{
    public class LDAPSettings
    {
        public string Hostname { get; set; }
        public int Port { get; set; } = 389; // Default SFTP port
        public string Domain { get; set; }

        public string Path { get; set; }
        public string Server { get; set; }  
        public string UserDomainName { get; set; }

        public string BaseDn { get; set; }
        public string BindDn { get; set; }  
        public string BindPassword { get; set; }

        public string RootDn { get; set; }
        public string SearchFilter { get; set; }


    }
}

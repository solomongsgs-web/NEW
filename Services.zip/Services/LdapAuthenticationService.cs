﻿using Novell.Directory.Ldap;
using Microsoft.Extensions.Configuration;
using System;
using System.Diagnostics.Eventing.Reader;
using CTS_WEB.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NuGet.DependencyResolver;
using System.IO;
using System.IO;
using System.Runtime.Intrinsics.X86;
using System.Threading.Tasks;

namespace CTS_WEB.Services
{
    public class LdapAuthenticationService
    {
        private readonly IConfiguration _configuration;
        private IConfigurationSection LDAPSettings;
        private readonly LDAPSettings _settings;
        private readonly ILogger<LdapAuthenticationService> _logger;
        private readonly AppDBContext _context;
        public LdapAuthenticationService(IOptions<LDAPSettings> settings, ILogger<LdapAuthenticationService> logger, IConfiguration configuration, AppDBContext context)
        {
            _settings = settings.Value;
            _logger = logger;
            _configuration = configuration;
            _context = context;
        }
        public IConfigurationSection GetLdapSettings()
        {
            return LDAPSettings;
        }

        public bool Authenticate(string username, string password)
        {
            try
            {
                var settings = _configuration.GetSection("LdapSettings");

                var server = settings["Server"];
                var hostname = settings["Hostname"];
                var port = settings["Port"];
                var domain = settings["Domain"];
                var path = settings["Path"];
                var userdomain = settings["UserDomainName"];
                var basedn = settings["BaseDn"];
                var binddn = settings["BindDn"];
                var bindpassword = settings["BindPassword"];
                var rootdn = settings["RootDn"];
                var searchfilter = string.Format(settings["SearchFilter"], username);


                using var connection = new LdapConnection { SecureSocketLayer = false };
                connection.Connect(server, LdapConnection.DEFAULT_PORT);
                connection.Bind(binddn, bindpassword);

                var searchResults = connection.Search(basedn, LdapConnection.SCOPE_SUB, searchfilter, null, false);
      
                if (searchResults.hasMore())
                {
                    var user = searchResults.next();
                    connection.Bind(user.DN, password);
                    return true;
                }
                return false;
            }
            catch (LdapException e)
            {
                return false;
            }
            finally
            {
                
            }
        }
    }
}

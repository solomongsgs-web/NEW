﻿using Microsoft.Extensions.Configuration;
using ServiceReference1;
using System.ServiceModel;
using CTS_WEB.Models;

namespace CTS_WEB.Controllers
{
    public class WcfClientService
    {
        private readonly IConfiguration _configuration;

        public WcfClientService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        //async Task<string>
        public string CallValidation(string strUser, string strPass)
        {
            // strResult = string.Empty;
            string username = _configuration["WcfServiceCredentials:Username"];
            string password = _configuration["WcfServiceCredentials:Password"];
            string serviceUrl = _configuration["WcfServiceCredentials:ServiceUrl"]; // Assuming you also store the URL
            
            var binding = new BasicHttpBinding();
 
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic; // Or HttpClientCredentialType.Windows if using AD

            var endpointAddress = new EndpointAddress(serviceUrl);
 
            var client = new ServiceReference1.ADserviceSoapClient(binding, endpointAddress);

            client.ClientCredentials.UserName.UserName = username;
            client.ClientCredentials.UserName.Password = password;
            // Treat the test certificate as trusted.
            client.ClientCredentials.ServiceCertificate.Authentication.CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.PeerOrChainTrust;
            // Call the service operation using the proxy
            try
            {
                // Open client
                client.Open();
                //await client.OpenAsync();
                 

                var strResult = client.wsdlLoginAuth(strUser, strPass);
                //strResult = task.Result.wsdlADVerificationResult.ToString();


                return strResult.ToString();
            }
            catch (Exception ex)
            {
                // Handle exceptions
                return ex.Message;
            }
            finally
            {
                // Ensure the client is closed properly
                  //client.CloseAsync();
            }

        }

        public async Task CallWcfServiceAsync()
        {
            // 1. Retrieve credentials from configuration
            string username = _configuration["WcfServiceCredentials:Username"];
            string password = _configuration["WcfServiceCredentials:Password"];
            string serviceUrl = _configuration["WcfServiceCredentials:ServiceUrl"]; // Assuming you also store the URL

            // 2. Configure the binding and endpoint address
            // Use an appropriate binding (e.g., BasicHttpBinding, WSHttpBinding) based on your service's security settings
            var binding = new BasicHttpBinding();
            // If using transport security (HTTPS) and basic authentication, set the security mode
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic; // Or HttpClientCredentialType.Windows if using AD

            var endpointAddress = new EndpointAddress(serviceUrl);

            // 3. Create the WCF client proxy
            // Replace 'YourSoapClient' with the actual name of your generated client proxy class
            var client = new ServiceReference1.ADserviceSoapClient(binding, endpointAddress);

            // 4. Supply the credentials programmatically
            client.ClientCredentials.UserName.UserName = username;
            client.ClientCredentials.UserName.Password = password;

            // If you are connecting to Active Directory (AD) using Windows credentials, you might use:
            // client.ClientCredentials.Windows.ClientCredential = new NetworkCredential(username, password, "YOUR_DOMAIN");


            // 5. Call the service operation
            try
            {
                // Replace 'YourOperationAsync' with the actual method name from your WCF service
                            
                await client.OpenAsync();
            }
            catch (Exception ex)
            {
                // Handle exceptions
            }
            finally
            {
                // Ensure the client is closed properly
                await client.CloseAsync();
            }
        }
    }

}
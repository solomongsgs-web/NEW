﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Xsl;


namespace CTS_WEB
{
    public class clsBranch
    {
        public double Id { get; set; }
        public string Brstn { get; set; }
        public string BranchName { get; set; }

        public System.Data.DataTable SortedTable;
        public System.Data.DataTable tblDET;
        public System.Data.DataTable tblSORT;
        public System.Data.DataTable tblBRANCH;
        private string NEW_FILE;
        private int LINECOUNT;
        private int PAGELINECOUNT;
        private int TOTALPAGE;
        private decimal decBRANCHAMOUNTTOTAL = 0;
        private decimal decPAGETOTAL = 0;
        private string[] Temp1 = new string[20000];
        private string[] Temp2 = new string[20000];
        private string[] Temp3 = new string[20000];
        private string[] Temp = new string[20000];
        private string[] Sort1 = new string[20000];
        private int iTOTALITEMS = 0;
        private static Dictionary<string, int> ProgressTracker = new Dictionary<string, int>();
        public System.Data.DataTable CopyBranchTable(SqlConnection con)
        {

            string destinationTableName = "Branches_SI";
            string query = "SELECT * FROM Branches_SI";
            using (con)
            {

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {
                    bulkCopy.DestinationTableName = destinationTableName;



                    try
                    {
                        // The SqlDataAdapter can be initialized with the query and connection
                        using (SqlDataAdapter adapter = new SqlDataAdapter(query, con))
                        {
                            // The Fill method opens the connection, executes the SelectCommand,
                            // and populates the DataTable with the results.
                            adapter.Fill(tblBRANCH);
                        }

                        return tblBRANCH;

                        //Console.WriteLine("Successfully wrote DataTable to SQL Server table.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error during bulk copy: {ex.Message}");
                    }
                }
            }
            return tblBRANCH;
        }
        public System.Data.DataTable CreateTableBRANCH()
        {

            // Create a new DataTable.
            // 
            // 1. Create a new DataTable
            tblBRANCH = new System.Data.DataTable("Branches_SI");

            tblBRANCH.Columns.Add("SEQ", typeof(double));
            tblBRANCH.Columns.Add("BRCODE", typeof(string));
            tblBRANCH.Columns.Add("BRACRO", typeof(string));
            tblBRANCH.Columns.Add("REGION", typeof(string));
            tblBRANCH.Columns.Add("BRNAME", typeof(string));
            tblBRANCH.Columns.Add("NEWBRSTN", typeof(string));
            tblBRANCH.Columns.Add("OLDBRSTN", typeof(string));
            tblBRANCH.Columns.Add("AREA", typeof(string));
            tblBRANCH.Columns.Add("OLDNAME", typeof(string));
            tblBRANCH.Columns.Add("ORDERING", typeof(int));

            return tblBRANCH;
        }
        public System.Data.DataTable CreateTableDET()
        {
            // Create a new DataTable.
            // 
            // 1. Create a new DataTable
            tblDET = new System.Data.DataTable("DET");

            // 2. Create a DataColumn object
            DataColumn IdColumn = new DataColumn("RID", typeof(string));
            IdColumn.MaxLength = 2; // Limits input to 2 characters       
            tblDET.Columns.Add(IdColumn);

            DataColumn ChkNoColumn = new DataColumn("CHKNO", typeof(string));
            ChkNoColumn.MaxLength = 10;
            tblDET.Columns.Add(ChkNoColumn);

            DataColumn DrColumn = new DataColumn("DRBRCH", typeof(string));
            DrColumn.MaxLength = 9;
            tblDET.Columns.Add(DrColumn);

            DataColumn AcColumn = new DataColumn("ACCTNO", typeof(string));
            AcColumn.MaxLength = 12;
            tblDET.Columns.Add(AcColumn);

            DataColumn TcColumn = new DataColumn("TCODE", typeof(string));
            TcColumn.MaxLength = 3;
            tblDET.Columns.Add(TcColumn);

            DataColumn AmtColumn = new DataColumn("TAMT", typeof(string));
            AmtColumn.MaxLength = 12;
            tblDET.Columns.Add(AmtColumn);

            DataColumn SrColumn = new DataColumn("SERIES", typeof(string));
            SrColumn.MaxLength = 6;
            tblDET.Columns.Add(SrColumn);

            DataColumn BrColumn = new DataColumn("BRSTN", typeof(string));
            BrColumn.MaxLength = 5;
            tblDET.Columns.Add(BrColumn);

            DataColumn FrColumn = new DataColumn("FILLER", typeof(string));
            FrColumn.MaxLength = 5;
            tblDET.Columns.Add(FrColumn);

            return tblDET;

        }

        public string GetDateMMDDYY(string strDate)
        {
            string strNewDate = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strNewDate = strMM + strDD + strYY;
            return strNewDate;
        }
        public string GetDateString(string strDate)
        {
            string strNewDate = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strNewDate = strYY + strMM + strDD;
            return strNewDate;
        }
        public string GetYear(string strDate)
        {
            string strYear = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strYear = strYY;
            return strYear;
        }
        public string GetMonthFolder(string strDate)
        {
            string strMonth = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            string sDate = strYY + strMM + strDD;
            string newDate = string.Empty;
            //20201210
            strDD = sDate.Substring(6, 2).ToString();
            strMM = sDate.Substring(4, 2).ToString();
            strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            return newDate;
        }


        public int ReadFileCountBRSTN(string sFileName)
        {
            System.Data.DataTable tblBRSTN = new System.Data.DataTable("BRSTN");
            string TextLine = string.Empty;
            string TempLine = string.Empty;
            string NewLine = string.Empty;
            string NextLine = string.Empty;
            string sDate = string.Empty;
            string sDetail = string.Empty;
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";

            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";

            string strBRSTN = "";
            string strTotalItemsBranch = "";
            int TotalItemsPerBranch = 0;
            int TempCtr = 0;
            int xctr = 0;

            int LCTR = 0;


            if (System.IO.File.Exists(sFileName) == true)
            {
                // Create a new DataTable.
                // 
                // 1. Create a new DataTable


                // 2. Create a DataColumn object
                DataColumn IdColumn = new DataColumn("RID", typeof(string));
                IdColumn.MaxLength = 2; // Limits input to 2 characters       
                tblBRSTN.Columns.Add(IdColumn);

                DataColumn ChkNoColumn = new DataColumn("CHKNO", typeof(string));
                ChkNoColumn.MaxLength = 10;
                tblBRSTN.Columns.Add(ChkNoColumn);

                DataColumn DrColumn = new DataColumn("DRBRCH", typeof(string));
                DrColumn.MaxLength = 9;
                tblBRSTN.Columns.Add(DrColumn);

                DataColumn AcColumn = new DataColumn("ACCTNO", typeof(string));
                AcColumn.MaxLength = 12;
                tblBRSTN.Columns.Add(AcColumn);

                DataColumn TcColumn = new DataColumn("TCODE", typeof(string));
                TcColumn.MaxLength = 3;
                tblBRSTN.Columns.Add(TcColumn);

                DataColumn AmtColumn = new DataColumn("TAMT", typeof(string));
                AmtColumn.MaxLength = 12;
                tblBRSTN.Columns.Add(AmtColumn);

                DataColumn SrColumn = new DataColumn("SERIES", typeof(string));
                SrColumn.MaxLength = 6;
                tblBRSTN.Columns.Add(SrColumn);

                DataColumn BrColumn = new DataColumn("BRSTN", typeof(string));
                BrColumn.MaxLength = 5;
                tblBRSTN.Columns.Add(BrColumn);

                DataColumn FrColumn = new DataColumn("FILLER", typeof(string));
                FrColumn.MaxLength = 5;
                tblBRSTN.Columns.Add(FrColumn);


                System.IO.StreamReader objReader = new System.IO.StreamReader(sFileName);

                while (objReader.Peek() != -1)
                {
                    TextLine = objReader.ReadLine();
                    if (TextLine.ToString().Trim().Length > 0)
                    {
                        RID = TextLine.Substring(0, 2);
                        CHKNO = TextLine.Substring(2, 10);
                        DRBRCH = TextLine.Substring(12, 9);
                        ACCTNO = TextLine.Substring(21, 12);
                        TCODE = TextLine.Substring(33, 3);
                        TAMT = TextLine.Substring(36, 12);
                        SERIES = TextLine.Substring(48, 6);
                        BRSTN = TextLine.Substring(54, 5);
                        FILLER = TextLine.Substring(59, 5);
                        xctr = xctr + 1;
                        if (RID == "BF")
                        {
                            //Get Date
                            sDate = TextLine.Substring(2, 8);
                            //string sNewFile = CreateNewFile(strNewFile, TextLine);
                            //Convert Date
                            sDate = ConvDate(sDate);

                        }
                        else
                        {
                            //DETAILS
                            if (RID == "01")
                            {
                                tblBRSTN.Rows.Add(RID, CHKNO, DRBRCH, ACCTNO, TCODE, TAMT, SERIES, BRSTN, FILLER);
                                //Temp1[TempCtr] = TextLine;
                                //TempCtr = TempCtr + 1;

                            }

                            if (RID == "BR")
                            {
                                //DONT SAVE

                            }

                        }
                    }
                    LCTR++;
                }
                objReader.Close();
            }
            else
            {
                //MessageBox.Show("File Not Found", "File Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            LCTR = tblBRSTN.Rows.Count;
            if (tblBRSTN.Rows.Count > 0)
            {
                tblBRSTN.DefaultView.Sort = "DRBRCH, ACCTNO, CHKNO ASC";
                tblBRSTN = tblBRSTN.DefaultView.ToTable();

                List<string> distinctValuesList = tblBRSTN.AsEnumerable()
                                                        .Select(static row => row.Field<string>("DRBRCH"))
                                                        .Distinct()
                                                        .ToList();

                LCTR = distinctValuesList.Count;
            }

            return LCTR;
        }

        public void WriteDataTableToTextFile(DataTable dt, string filePath, string delimiter)
        {
            // Use StreamWriter to write to the file
            using (StreamWriter sw = new StreamWriter(filePath, false))
            {
                // 1. Write the header row
                // Select column names and join them with the delimiter
                IEnumerable<string> columnNames = dt.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                //sw.WriteLine(string.Join(delimiter, columnNames));

                // 2. Write the data rows
                foreach (DataRow row in dt.Rows)
                {
                    // Select item array values (objects) and convert them to strings
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    sw.WriteLine(string.Join(delimiter, fields));
                }
                sw.Close();
            }

        }

        public void WRITEPAGE(int iStart, int iEnd, int iSize, string sBRNAME, string strBRSTN, string sDate, int iPAGECTR, int iTOTALPAGE, bool EndPage, string SOURCE_FOLDER)
        {
            int ItemSize = iSize;
            int itemCtr = 0;
            int NoRowSpace = 0;
            decimal dAMOUNT = 0;
            string sAMT = "";
            NoRowSpace = iSize % 50;
            if (NoRowSpace > 0)
            {
                NoRowSpace = 50 - NoRowSpace;
            }
            string TempLine = string.Empty;
            WriteHeader(sBRNAME, strBRSTN, sDate, iPAGECTR, iTOTALPAGE, SOURCE_FOLDER);
            PAGELINECOUNT = PAGELINECOUNT + 10;
            for (int ctr = iStart; ctr < iEnd; ctr++)
            {
                TempLine = Temp2[ctr].ToString();
                WriteToFile(SOURCE_FOLDER, strBRSTN, TempLine);
                PAGELINECOUNT = PAGELINECOUNT + 1;
                //Compute for Page Total
                if (TempLine.Trim().Length > 0)
                {
                    //string[] pdate = TempLine.Split(' ');
                    //sAMT = pdate[3].ToString();
                    if (TempLine.Contains("ACCOUNT TOTAL") == true)
                    {

                    }
                    else
                    {
                        sAMT = TempLine.Substring(82, 20);
                        sAMT = sAMT.Trim();
                        dAMOUNT = Convert.ToDecimal(sAMT);
                        decPAGETOTAL = decPAGETOTAL + dAMOUNT;
                        itemCtr++;
                    }
                }
            }//TEMP BRSTN FILE  For Loop
            if (NoRowSpace > 0)
            {
                for (int rep = 1; rep <= NoRowSpace; rep++)
                {
                    TempLine = "                                                                                                                                   ";
                    WriteToFile(SOURCE_FOLDER, strBRSTN, TempLine);
                    PAGELINECOUNT = PAGELINECOUNT + 1;
                }
            }

            if (EndPage == true)
            {
                WriteFooterTotal(sBRNAME, strBRSTN, itemCtr, iTOTALITEMS, decPAGETOTAL, decBRANCHAMOUNTTOTAL, SOURCE_FOLDER);
            }
            else
            {
                WriteFooter(sBRNAME, strBRSTN, itemCtr, iTOTALITEMS, decPAGETOTAL, decBRANCHAMOUNTTOTAL, SOURCE_FOLDER);
            }

        }
        public void WriteFooter(string BRNAME, string BRSTN, int iPage, int iPageTotal, decimal TotAmount, decimal BranchTotal, string SOURCE_FOLDER)
        {
            /*       
             _________________________________________________________________________________________________________________________________
            TO: PNB - MANILA - ESCOLTA                    BRSTN 01008 - 001           Page Count:       27         Page Amount:        5,232,095.64
            ACCUMULATED TOTALS FOR:                       BRSTN 01008 - 001          Total Count:       27        Total Amount:        5,232,095.64
            */
            string sDETAIL = string.Empty;
            //sDETAIL = "-----------------------------------------------------------------------------------------------------------------------------------";
            sDETAIL = "____________________________________________________________________________________________________________________________________________";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "TO: PNB - " + BRNAME.PadRight(34, ' ') + "BRSTN " + BRSTN + "          " + " Page Count:" + iPage.ToString().PadLeft(9, ' ') + "         " + "Page Amount:" + TotAmount.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            //sDETAIL = "ACCUMULATED TOTALS FOR:                     " + "BRSTN " + BRSTN + "          " + "Total Count:" + iPageTotal.ToString().PadLeft(9, ' ') + "        " + "Total Amount:" + BranchTotal.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            //WriteToFile(BRSTN, sDETAIL);
        }
        public void WriteFooterTotal(string BRNAME, string BRSTN, int iPage, int iPageTotal, decimal TotAmount, decimal BranchTotal, string SOURCE_FOLDER)
        {
            /*       
             _________________________________________________________________________________________________________________________________
            TO: PNB - MANILA - ESCOLTA                    BRSTN 01008 - 001           Page Count:       27         Page Amount:        5,232,095.64
            ACCUMULATED TOTALS FOR:                       BRSTN 01008 - 001          Total Count:       27        Total Amount:        5,232,095.64
            */
            string sDETAIL = string.Empty;
            //sDETAIL = "-----------------------------------------------------------------------------------------------------------------------------------";
            sDETAIL = "____________________________________________________________________________________________________________________________________________";
            //   ---------

            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "TO: PNB - " + BRNAME.PadRight(34, ' ') + "BRSTN " + BRSTN + "          " + " Page Count:" + iPage.ToString().PadLeft(9, ' ') + "         " + "Page Amount:" + TotAmount.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "ACCUMULATED TOTALS FOR:                     " + "BRSTN " + BRSTN + "          " + "Total Count:" + iPageTotal.ToString().PadLeft(9, ' ') + "        " + "Total Amount:" + BranchTotal.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
        }
        public void WriteToFile(string SOURCE_FOLDER, string Brstn, string strLine)
        {
            string NewFileName = string.Empty;
            string filePath = SOURCE_FOLDER + "\\" + Brstn + ".DET";

            NewFileName = filePath;
            if (!System.IO.File.Exists(NewFileName))
            {
                using (StreamWriter sw = System.IO.File.CreateText(NewFileName))
                {
                    sw.WriteLine(strLine);
                    sw.Close();
                }
            }
            else if (System.IO.File.Exists(NewFileName))
            {
                //TextWriter tw = new StreamWriter(NewFileName);
                //tw.WriteLine(TextLine);
                //tw.Close();
                using (StreamWriter w = System.IO.File.AppendText(NewFileName))
                {
                    w.WriteLine(strLine);
                }
            }
        }

        public void WriteHeader(string BRNAME, string BRSTN, string sDate, int iPage, int iPTotal, string SOURCE_FOLDER)
        {
            string sDETAIL = string.Empty;
            string newBRSTN = BRSTN.Substring(0, 5) + "-" + BRSTN.Substring(5, 3);
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //1
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //2
                                                        //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            sDETAIL = "DATE : " + sDate + "                  CICS Detail List of Branch Inward Regular Clearing Items                " + "PAGE : " + iPage.ToString().PadLeft(7, ' ') + " of " + iPTotal.ToString();
            //1234567     890123456789      0123456789012345678901234567890123456789012345678901234567890  12345678901234567890123456789012345678901234567890
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);  //3
            //sDETAIL = "                                                " + "GREATER MANILA ELECTRONIC CLEARING SYSTEM";
            //WriteToFile(BRSTN, sDETAIL);
            //sDETAIL = " ";
            //WriteToFile(BRSTN, sDETAIL);
            //sDETAIL = "                                       CICS Detail List of Branch Inward Regular Clearing Items";
            //WriteToFile(BRSTN, sDETAIL);
            sDETAIL = "                                  To: " + "PNB - " + BRNAME.PadRight(35, ' ') + "BRSTN " + newBRSTN;
            //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            //CALOOCAN-SANGANDAAN               BRSTN 01008-003
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //4  
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //5
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //6   1234567890 
                                                        //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            sDETAIL = "                    Cheque No.                  Account No.               TC              Amount              Sender's BIN";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //7
            sDETAIL = "--------------------------------------------------------------------------------------------------------------------------------------------";  //---------
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //8
        }


        public void CopyBranchTable(SqlConnection con, System.Data.DataTable tblBRANCH)
        {

            string destinationTableName = "Branches_SI";
            string query = "SELECT * FROM Branches_SI";
            using (con)
            {

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {
                    bulkCopy.DestinationTableName = destinationTableName;



                    try
                    {
                        // The SqlDataAdapter can be initialized with the query and connection
                        using (SqlDataAdapter adapter = new SqlDataAdapter(query, con))
                        {
                            // The Fill method opens the connection, executes the SelectCommand,
                            // and populates the DataTable with the results.
                            adapter.Fill(tblBRANCH);
                        }



                        //Console.WriteLine("Successfully wrote DataTable to SQL Server table.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error during bulk copy: {ex.Message}");
                    }
                }
            }
        }
        public System.Data.DataTable CreateTableSORT()
        {
            // Create a new DataTable.
            // 
            // 1. Create a new DataTable
            tblSORT = new System.Data.DataTable("SORT");

            // 2. Create a DataColumn object
            DataColumn IdColumn = new DataColumn("RID", typeof(string));
            IdColumn.MaxLength = 2; // Limits input to 2 characters       
            tblSORT.Columns.Add(IdColumn);

            DataColumn ChkNoColumn = new DataColumn("CHKNO", typeof(string));
            ChkNoColumn.MaxLength = 10;
            tblSORT.Columns.Add(ChkNoColumn);

            DataColumn DrColumn = new DataColumn("DRBRCH", typeof(string));
            DrColumn.MaxLength = 9;
            tblSORT.Columns.Add(DrColumn);

            DataColumn AcColumn = new DataColumn("ACCTNO", typeof(string));
            AcColumn.MaxLength = 12;
            tblSORT.Columns.Add(AcColumn);

            DataColumn TcColumn = new DataColumn("TCODE", typeof(string));
            TcColumn.MaxLength = 3;
            tblSORT.Columns.Add(TcColumn);

            DataColumn AmtColumn = new DataColumn("TAMT", typeof(string));
            AmtColumn.MaxLength = 12;
            tblSORT.Columns.Add(AmtColumn);

            DataColumn SrColumn = new DataColumn("SERIES", typeof(string));
            SrColumn.MaxLength = 6;
            tblSORT.Columns.Add(SrColumn);

            DataColumn BrColumn = new DataColumn("BRSTN", typeof(string));
            BrColumn.MaxLength = 5;
            tblSORT.Columns.Add(BrColumn);

            DataColumn FrColumn = new DataColumn("FILLER", typeof(string));
            FrColumn.MaxLength = 5;
            tblSORT.Columns.Add(FrColumn);

            return tblSORT;

        }


        public void AddNewRowToDataTableBR(string sDETAIL, System.Data.DataTable tblSORT)
        {
            DataRow newRow = tblSORT.NewRow(); // Create a new row with the table's schema
                                               //BR 0100800100 000046000 0455825914200000000000000373586000000000000"

            newRow["RID"] = sDETAIL.Substring(0, 2);
            newRow["CHKNO"] = sDETAIL.Substring(2, 10);
            newRow["DRBRCH"] = sDETAIL.Substring(12, 9);
            newRow["ACCTNO"] = sDETAIL.Substring(21, 12);
            newRow["TCODE"] = sDETAIL.Substring(33, 3);
            newRow["TAMT"] = sDETAIL.Substring(36, 12);
            newRow["SERIES"] = sDETAIL.Substring(48, 6);
            newRow["BRSTN"] = sDETAIL.Substring(54, 5);
            newRow["FILLER"] = sDETAIL.Substring(59, 5);

            tblSORT.Rows.Add(newRow);
        }
        public void AddNewRowToDataTable(DataRow dtRow, System.Data.DataTable tblSORT)
        {
            DataRow newRow = tblSORT.NewRow(); // Create a new row with the table's schema
            newRow["RID"] = dtRow[0].ToString();              // Set values using column names
            newRow["CHKNO"] = dtRow[1].ToString();
            newRow["DRBRCH"] = dtRow[2].ToString();
            newRow["ACCTNO"] = dtRow[3].ToString();              // Set values using column names
            newRow["TCODE"] = dtRow[4].ToString();
            newRow["TAMT"] = dtRow[5].ToString();
            newRow["SERIES"] = dtRow[6].ToString();              // Set values using column names
            newRow["BRSTN"] = dtRow[7].ToString();
            newRow["FILLER"] = dtRow[8].ToString();

            tblSORT.Rows.Add(newRow);           // 
        }
        public int INSERTSPACETOFILE(string[] ArrTEMP, int ArrSize)
        {
            //Number of Lines
            int LineCtr = 0;
            string AcctNo = "";
            string NextAcctNo = "";
            string PrevAcctNo = "";
            string strAmt = "";
            decimal dAmt = 0;
            int LenArray = ArrTEMP.Length;
            decimal dAmtTotal = 0;
            decimal decACCTTOTAL = 0;
            string sRID = "";
            string sCHKNO = "";
            string sDRBRCH = "";
            string sACCTNO = "";
            string sTCODE = "";
            string sTAMT = "";
            string sconvTAMT = "";
            string sSERIES = "";
            string sBRSTN = "";
            string sFILLER = "";
            string detLine = string.Empty;
            string nexLine = string.Empty;
            string newLine = string.Empty;
            int ItemCount = 0;
            int iCtr = 0;
            InitArray2();

            for (int x = 0; x < ArrSize; x++)
            {
                detLine = ArrTEMP[x].ToString();

                sRID = detLine.Substring(0, 2);
                sCHKNO = detLine.Substring(2, 10);
                sDRBRCH = detLine.Substring(12, 9);
                sACCTNO = detLine.Substring(21, 12);
                sTCODE = detLine.Substring(33, 3);
                sTAMT = detLine.Substring(36, 12);
                sSERIES = detLine.Substring(48, 6);
                sBRSTN = detLine.Substring(54, 5);
                sFILLER = detLine.Substring(59, 5);

                AcctNo = detLine.Substring(21, 12);
                strAmt = detLine.Substring(36, 12);
                dAmt = Convert.ToDecimal(strAmt);
                dAmt = dAmt / 100;
                dAmtTotal = dAmtTotal + dAmt;
                sconvTAMT = dAmt.ToString("#,###,###,###,##0.00");
                if (x == ArrSize - 1)
                {
                    NextAcctNo = PrevAcctNo;
                }
                else
                {
                    nexLine = ArrTEMP[x + 1].ToString(); //Check Next Line
                    NextAcctNo = nexLine.Substring(21, 12);
                }

                if (NextAcctNo.Length > 0)
                {
                    if (AcctNo == NextAcctNo)  //SAME ACCTNO
                    {

                        //12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567
                        newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                        Temp2[iCtr] = newLine; //item
                        ItemCount = ItemCount + 1;  //counter  
                        decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals        
                        PrevAcctNo = AcctNo;
                        iCtr++;

                    }
                    else  //NEXT ACCTNO IS DIFFERENT 
                    {
                        //WRITE ACCOUNT TOTAL and TOTAL COUNT
                        if (ItemCount >= 1)
                        {
                            //12345678901234567890123456789012345678901234567890123
                            newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                            Temp2[iCtr] = newLine; //item
                            ItemCount = ItemCount + 1; //counter
                            iCtr++;
                            decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals       
                                                                 //12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
                            newLine = "                    " + "ACCOUNT TOTAL --> COUNT:" + ItemCount.ToString().PadLeft(8, ' ') + "  AMOUNT:     " + decACCTTOTAL.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
                            Temp2[iCtr] = newLine; //totals
                            iCtr++;
                            Temp2[iCtr] = "";
                            iCtr++;
                            ItemCount = 0;
                            decACCTTOTAL = 0;
                        }
                        else
                        {
                            //12345678901234567890123456789012345678901234567890123
                            newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                            Temp2[iCtr] = newLine; //item
                            iCtr++;
                            Temp2[iCtr] = "";
                            iCtr++;
                        }
                        PrevAcctNo = AcctNo;
                    }
                }
                else  //ONE ITEM ONLY 
                {
                    newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                    Temp2[iCtr] = newLine; //item
                    ItemCount = ItemCount + 1;  //counter  
                    decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals        
                    PrevAcctNo = AcctNo;
                    iCtr++;
                }
            }
            return iCtr;
        }

        public int READARRAYFILE(string[] ArrTEMP, int ArrSize)
        {
            //Number of Lines
            int LineCtr = 0;
            string AcctNo = "";
            string NextAcctNo = "";
            string PrevAcctNo = "";
            string strAmt = "";
            decimal dAmt = 0;
            int LenArray = ArrTEMP.Length;
            decimal dAmtTotal = 0;


            string detLine = string.Empty;
            string nexLine = string.Empty;
            int ItemCount = 0;
            if (ArrSize == 0)
            {
                //for (int x = 0; x < ArrSize; x++)
                // {
                detLine = ArrTEMP[0].ToString();
                AcctNo = detLine.Substring(21, 12);
                strAmt = detLine.Substring(36, 12);
                dAmt = Convert.ToDecimal(strAmt);
                dAmt = dAmt / 100;
                dAmtTotal = dAmtTotal + dAmt;

                if (NextAcctNo.Length > 0)
                {
                    if (AcctNo == NextAcctNo)  //SAME ACCTNO
                    {
                        LineCtr = LineCtr + 1;
                        ItemCount = ItemCount + 1;
                    }
                    else  //NEXT ACCTNO IS DIFFERENT 
                    {
                        //WRITE ACCOUNT TOTAL and TOTAL COUNT
                        if (ItemCount >= 1)
                        {
                            LineCtr = LineCtr + 1; //Item
                            LineCtr = LineCtr + 1; //Totals
                            ItemCount = ItemCount + 1;
                            LineCtr = LineCtr + 1; //SPACE
                            ItemCount = 0;
                        }
                        else
                        {
                            LineCtr = LineCtr + 1; //Item
                            LineCtr = LineCtr + 1; //SPACE
                        }
                        PrevAcctNo = AcctNo;
                    }
                }
                //}
            }
            else
            {
                for (int x = 0; x < ArrSize; x++)
                {
                    detLine = ArrTEMP[x].ToString();
                    AcctNo = detLine.Substring(21, 12);
                    strAmt = detLine.Substring(36, 12);
                    dAmt = Convert.ToDecimal(strAmt);
                    dAmt = dAmt / 100;
                    dAmtTotal = dAmtTotal + dAmt;
                    if (x == ArrSize - 1)
                    {
                        NextAcctNo = PrevAcctNo;
                    }
                    else
                    {
                        nexLine = ArrTEMP[x + 1].ToString(); //Check Next Line
                        NextAcctNo = nexLine.Substring(21, 12);
                    }
                    if (NextAcctNo.Length > 0)
                    {
                        if (AcctNo == NextAcctNo)  //SAME ACCTNO
                        {
                            LineCtr = LineCtr + 1;
                            ItemCount = ItemCount + 1;
                        }
                        else  //NEXT ACCTNO IS DIFFERENT 
                        {
                            //WRITE ACCOUNT TOTAL and TOTAL COUNT
                            if (ItemCount >= 1)
                            {
                                LineCtr = LineCtr + 1; //Item
                                LineCtr = LineCtr + 1; //Totals
                                ItemCount = ItemCount + 1;
                                LineCtr = LineCtr + 1; //SPACE
                                ItemCount = 0;
                            }
                            else
                            {
                                LineCtr = LineCtr + 1; //Item
                                LineCtr = LineCtr + 1; //SPACE
                            }
                            PrevAcctNo = AcctNo;
                        }
                    }
                    else
                    {
                        LineCtr = LineCtr + 1; //1 Item
                    }
                }
            }



            decBRANCHAMOUNTTOTAL = dAmtTotal;
            return LineCtr;


        }
        public void SortArray(int ArrSize)
        {
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";
            //string convTAMT = "";
            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";
            string TextLine = string.Empty;
            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("RID");
            dt.Columns.Add("CHKNO");
            dt.Columns.Add("DRBRCH");
            dt.Columns.Add("ACCTNO");
            dt.Columns.Add("TCODE");
            dt.Columns.Add("TAMT");
            dt.Columns.Add("SERIES");
            dt.Columns.Add("BRSTN");
            dt.Columns.Add("FILLER");

            for (int ax = 0; ax <= ArrSize; ax++)
            {
                TextLine = Temp[ax].ToString();
                DataRow _ravi = dt.NewRow();
                RID = TextLine.Substring(0, 2);
                CHKNO = TextLine.Substring(2, 10);
                DRBRCH = TextLine.Substring(12, 9);
                ACCTNO = TextLine.Substring(21, 12);
                TCODE = TextLine.Substring(33, 3);
                TAMT = TextLine.Substring(36, 12);
                SERIES = TextLine.Substring(48, 6);
                BRSTN = TextLine.Substring(54, 5);
                FILLER = TextLine.Substring(59, 5);
                _ravi["RID"] = RID.Trim();
                _ravi["CHKNO"] = CHKNO.Trim();
                _ravi["DRBRCH"] = DRBRCH.Trim();
                _ravi["ACCTNO"] = ACCTNO.Trim();
                _ravi["TCODE"] = TCODE.Trim();
                _ravi["TAMT"] = TAMT.Trim();
                _ravi["SERIES"] = SERIES.Trim();
                _ravi["BRSTN"] = BRSTN.Trim();
                _ravi["FILLER"] = FILLER.Trim();
                dt.Rows.Add(_ravi);
            }

            dt.DefaultView.Sort = "ACCTNO, CHKNO";

            for (int bx = 0; bx < dt.Rows.Count; bx++)
            {
                TextLine = "";
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    TextLine = TextLine.Trim() + dt.Rows[bx][col].ToString().Trim();
                }
                Temp1[bx] = TextLine.Trim();
            }
        }

        public void InitArray()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp[x] = "";
            }
        }
        public void InitArray1()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp1[x] = "";
            }
        }
        public void InitArray2()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp2[x] = "";
            }
        }


        public void AddLineToNewFile(string sFileName, string BFDetail)
        {
            StreamWriter sw = null;
            string sDetail = "";
            if (System.IO.File.Exists(sFileName))
            {
                FileStream fs = System.IO.File.Open(sFileName, FileMode.Append, FileAccess.Write);
                StreamWriter sww = new StreamWriter(fs, System.Text.Encoding.UTF8);
                sDetail = BFDetail.Trim();
                sww.WriteLine(sDetail.ToString());
                sww.Close();
            }
            else
            {
                FileStream fs = System.IO.File.Open(sFileName, FileMode.CreateNew, FileAccess.Write);
                // generate a file stream with UTF8 characters
                sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
                sDetail = BFDetail.Trim();
                sw.WriteLine(sDetail.ToString());
                sw.Close();
            }
        }
        public string GetBeginningOfFile(string sFileName)
        {
            string TextLine = string.Empty;
            string NewLine = string.Empty;
            string NextLine = string.Empty;
            string sDate = string.Empty;
            string sDetail = string.Empty;
            string RID = "";

            if (System.IO.File.Exists(sFileName) == true)
            {

                System.IO.StreamReader objReader = new System.IO.StreamReader(sFileName);

                while (objReader.Peek() != -1)
                {
                    TextLine = objReader.ReadLine();
                    if (TextLine.ToString().Trim().Length > 0)
                    {
                        RID = TextLine.Substring(0, 2);

                        if (RID == "BF")
                        {
                            sDetail = TextLine.Trim();
                            objReader.Close();
                            break;
                        }
                    }
                }
            }
            return sDetail;
        }
        public int ReadFileCountDetailLines(string sFileName)
        {
            string TextLine = string.Empty;
            string TempLine = string.Empty;
            string NewLine = string.Empty;
            string NextLine = string.Empty;
            string sDate = string.Empty;
            string sDetail = string.Empty;
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";

            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";

            string strBRSTN = "";
            string strTotalItemsBranch = "";
            int TotalItemsPerBranch = 0;
            int TempCtr = 0;
            int xctr = 0;

            int LCTR = 0;
            if (System.IO.File.Exists(sFileName) == true)
            {

                System.IO.StreamReader objReader = new System.IO.StreamReader(sFileName);

                while (objReader.Peek() != -1)
                {
                    TextLine = objReader.ReadLine();
                    if (TextLine.ToString().Trim().Length > 0)
                    {
                        RID = TextLine.Substring(0, 2);
                        CHKNO = TextLine.Substring(2, 10);
                        DRBRCH = TextLine.Substring(12, 9);
                        ACCTNO = TextLine.Substring(21, 12);
                        TCODE = TextLine.Substring(33, 3);
                        TAMT = TextLine.Substring(36, 12);
                        SERIES = TextLine.Substring(48, 6);
                        BRSTN = TextLine.Substring(54, 5);
                        FILLER = TextLine.Substring(59, 5);
                        xctr = xctr + 1;
                        if (RID == "BF")
                        {
                            //Get Date
                            sDate = TextLine.Substring(2, 8);
                            //string sNewFile = CreateNewFile(strNewFile, TextLine);
                            //Convert Date
                            sDate = ConvDate(sDate);

                        }
                        else
                        {
                            //DETAILS
                            if (RID == "01")
                            {
                                tblDET.Rows.Add(RID, CHKNO, DRBRCH, ACCTNO, TCODE, TAMT, SERIES, BRSTN, FILLER);
                                //Temp1[TempCtr] = TextLine;
                                //TempCtr = TempCtr + 1;

                            }

                            if (RID == "BR")
                            {
                                //DONT SAVE

                            }

                        }
                    }
                    LCTR++;
                }
                objReader.Close();
            }
            else
            {
                //MessageBox.Show("File Not Found", "File Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            LCTR = tblDET.Rows.Count;
            return LCTR;
        }
        public string ConvDate(string sDate)
        {
            string newDate = string.Empty;
            //20201210
            string strDD = sDate.Substring(6, 2).ToString();
            string strMM = sDate.Substring(4, 2).ToString();
            string strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JAN";
                    break;
                case "02":
                    newDate = "FEB";
                    break;
                case "03":
                    newDate = "MAR";
                    break;
                case "04":
                    newDate = "APR";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUN";
                    break;
                case "07":
                    newDate = "JUL";
                    break;
                case "08":
                    newDate = "AUG";
                    break;
                case "09":
                    newDate = "SEP";
                    break;
                case "10":
                    newDate = "OCT";
                    break;
                case "11":
                    newDate = "NOV";
                    break;
                case "12":
                    newDate = "DEC";
                    break;
            }
            newDate = newDate + " " + strDD + ", " + strYY;
            return newDate;

            //MAR 25, 2022
        }
        public string ConvMonth(string sDate)
        {
            string newDate = string.Empty;
            //20201210
            string strDD = sDate.Substring(6, 2).ToString();
            string strMM = sDate.Substring(4, 2).ToString();
            string strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            //newDate = newDate + " " + strDD + ", " + strYY;
            return newDate;

            //MAR 25, 2022
        }

    }
}

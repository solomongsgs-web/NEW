﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Data.Odbc;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;


namespace CTS_WEB
{
    internal class ConnectionGenerator
    {
        public bool IsInitialized;


        private string _ConnectionString = "";
        private string _FTPIP = "";
        private string _FTPPath = "";
        private string _FTPUID = "";
        private string _FTPPass = "";
        private string _OutputFolder = "";
        private string _FTPPath1 = "";
        private string _FTPPath2 = "";
        private string _PKEY = "";
        private string _PIV = "";
        private string _winscpPath;

        private string _EncryptedPass = "";
        private string _DecryptedPass = "";

        public ConnectionGenerator()
        {
            IsInitialized = true;
            GetConfigValues();
            GetSqlConnection();
        }
        public string strConnectionString
        {
            get
            {
                return _ConnectionString;
            }
            set { _ConnectionString = value; }
        }
        public string strFTPIP
        {
            get
            {
                return _FTPIP;
            }
            set { _FTPIP = value; }
        }
        public string strFTPPath
        {
            get
            {
                return _FTPPath;
            }
            set { _FTPPath = value; }
        }

        public string strFTPUID
        {
            get
            {
                return _FTPUID;
            }
            set { _FTPUID = value; }
        }

        public string strFTPPass
        {
            get
            {
                return _FTPPass;
            }
            set { _FTPPass = value; }
        }
        public string strOutputFolder
        {
            get
            {
                return _OutputFolder;
            }
            set { _OutputFolder = value; }
        }

        public string strFTPPath1
        {
            get
            {
                return _FTPPath1;
            }
            set { _FTPPath1 = value; }
        }
        public string strFTPPath2
        {
            get
            {
                return _FTPPath2;
            }
            set { _FTPPath2 = value; }
        }

        public string strPKEY
        {
            get
            {
                return _PKEY;
            }
            set { _PKEY = value; }
        }
        public string strwinscpPath
        {
            get
            {
                return _winscpPath;
            }
            set { _winscpPath = value; }
        }
        public string strPIV
        {
            get
            {
                return _PIV;
            }
            set { _PIV = value; }
        }
        public string strEncryptedPass
        {
            get
            {
                return _EncryptedPass;
            }
            set { _EncryptedPass = value; }
        }

        public string strDecryptedPass
        {
            get
            {
                return _DecryptedPass;
            }
            set { _DecryptedPass = value; }
        }
        public string GetAppPath()
        {
            string strPath = AppDomain.CurrentDomain.BaseDirectory;
            return strPath;
        }
        public void GetConfigValues()
        {

            string TextLine = String.Empty;

            string AppPath = GetAppPath();

            string FILE_NAME = AppPath + "CONFIG.txt";

            if (System.IO.File.Exists(FILE_NAME) == true)
            {

                System.IO.StreamReader objReader = new System.IO.StreamReader(FILE_NAME);

                while (objReader.Peek() != -1)
                {
                    strConnectionString = objReader.ReadLine();
                    strFTPIP = objReader.ReadLine();
                    strFTPUID = objReader.ReadLine();
                    strFTPPass = objReader.ReadLine();
                    strOutputFolder = objReader.ReadLine();
                    strFTPPath1 = objReader.ReadLine();
                    strFTPPath2 = objReader.ReadLine();
                    strPKEY = objReader.ReadLine();
                    strPIV = objReader.ReadLine();
                    strEncryptedPass = strFTPPass;

                    strDecryptedPass = GetDecryptedValue(strFTPPass);

                    strwinscpPath = objReader.ReadLine();

                    break;
                }
            }
            else
            {
                //MessageBox.Show("File Not Found", "File Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        public string GetDecryptedValue(string ePassword)
        {
            strEncryptedPass = ePassword;
            byte[] Myencrypt = Convert.FromBase64String(strEncryptedPass.Trim());
            byte[] MyKey = Convert.FromBase64String(strPKEY.Trim());
            byte[] MyIV = Convert.FromBase64String(strPIV.Trim());
            strDecryptedPass = Decrypt1(Myencrypt, MyKey, MyIV);
            return strDecryptedPass;
        }
        public string GetEncryptedValue(string dPassword)
        {
            strDecryptedPass = dPassword;
            string encryptedPass = EncryptAesManaged(strDecryptedPass);
            strEncryptedPass = encryptedPass.Trim();
            return strEncryptedPass;
        }

        public string EncryptAesManaged(string sPass)
        {
            string EncryptedPass = string.Empty;
            try
            {
                // Create Aes that generates a new key and initialization vector (IV).    
                // Same key must be used in encryption and decryption    
                using (AesManaged aes = new AesManaged())
                {
                    // Encrypt string    
                    // Saving the KEY and IV


                    byte[] aKey = aes.Key;
                    byte[] aIV = aes.IV;

                    string strA = Convert.ToBase64String(aKey);
                    string strI = Convert.ToBase64String(aIV);
                    strPKEY = strA.Trim();
                    strPIV = strI.Trim();

                    byte[] encrypted = Encrypt1(sPass, aes.Key, aes.IV);
                    string strPass = Convert.ToBase64String(encrypted);

                    EncryptedPass = strPass.Trim();
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            return EncryptedPass;
        }

        public static byte[] Encrypt(byte[] buffer, byte[] sessionKey, out byte[] iv)
        {
            byte[] encrypted;
            iv = null;
            using (AesCryptoServiceProvider aesAlg = new AesCryptoServiceProvider { Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7 })
            {
                aesAlg.Key = sessionKey;
                iv = aesAlg.IV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(sessionKey, iv);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        csEncrypt.Write(buffer, 0, buffer.Length);

                        //This was not closing the cryptostream and only worked if I called FlushFinalBlock()
                        //encrypted = msEncrypt.ToArray(); 
                    }

                    encrypted = msEncrypt.ToArray();

                    return encrypted;
                }
            }
        }

        public static byte[] Encrypt1(string plainText, byte[] Key, byte[] IV)
        {
            byte[] encrypted;
            // Create a new AesManaged.    
            using (AesManaged aes = new AesManaged())
            {
                // Create encryptor    
                ICryptoTransform encryptor = aes.CreateEncryptor(Key, IV);
                aes.Padding = PaddingMode.None;
                // Create MemoryStream    
                using (MemoryStream ms = new MemoryStream())
                {
                    // Create crypto stream using the CryptoStream class. This class is the key to encryption    
                    // and encrypts and decrypts data from any given stream. In this case, we will pass a memory stream    
                    // to encrypt    
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        // Create StreamWriter and write data to a stream    
                        using (StreamWriter sw = new StreamWriter(cs))
                            sw.Write(plainText);
                        encrypted = ms.ToArray();
                    }
                }
            }
            // Return encrypted data    
            return encrypted;
        }
        public static string Decrypt1(byte[] cipherText, byte[] Key, byte[] IV)
        {
            string plaintext = null;
            // Create AesManaged    
            using (AesManaged aes = new AesManaged())
            {
                // Create a decryptor    
                ICryptoTransform decryptor = aes.CreateDecryptor(Key, IV);
                aes.Padding = PaddingMode.None;
                // Create the streams used for decryption.    
                using (MemoryStream ms = new MemoryStream(cipherText))
                {
                    // Create crypto stream    
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        // Read crypto stream    
                        using (StreamReader reader = new StreamReader(cs))
                            plaintext = reader.ReadToEnd();
                    }
                }
            }
            return plaintext;
        }
        private string GetExcelConnectionString(string excelFile)
        {
            //String connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excelFile + ";Extended Properties=Excel 8.0;";
            //return connString;
            System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
            builder.Add("Provider", "Microsoft.ACE.OLEDB.12.0");
            builder.Add("Data Source", excelFile);
            builder.Add("Extended Properties", "Excel 8.0");
            return builder.ConnectionString;
        }

        

        private string GetCSVConnectionString(string excelFile)
        {
            //String connString = "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + excelFile + "; Extended Properties = \"Text;HDR=YES;FMT=Delimited\"";                         
            //String connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;DataSource=" + excelFile + ";Extended Properties=text;HDR=Yes;FMT=Delimited");

            //String connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Text;HDR=Yes;IMEX=1\";", excelFile);
            //return connString;

            System.Data.Common.DbConnectionStringBuilder builder = new System.Data.Common.DbConnectionStringBuilder();
            builder.Add("Provider", "Provider=Microsoft.ACE.OLEDB.12.0");
            builder.Add("Data Source", excelFile);
            builder.Add("Extended Properties", "Extended Properties = \"Text;HDR=YES;IMEX=1\"");
            return builder.ConnectionString;

        }

       

        public void LogFailedTransfer(string sDetail, string sFileName)
        {

            string sdate = DateTime.Today.ToString("ddMMyyyy");

            StreamWriter sw = null;
            sFileName = sFileName + "\\" + "CTS_Log_" + sdate.ToString() + ".txt";
            //check if file exists
            if (File.Exists(sFileName))
            {
                FileStream fs = File.Open(sFileName, FileMode.Append, FileAccess.Write);
                StreamWriter sww = new StreamWriter(fs, System.Text.Encoding.UTF8);
                sww.WriteLine(sDetail.ToString());
                sww.Close();
            }
            else
            {
                FileStream fs = File.Open(sFileName, FileMode.CreateNew, FileAccess.Write);
                // generate a file stream with UTF8 characters
                sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
                sw.WriteLine("CTS Transaction Logs for the day : " + sdate.ToString());
                sw.WriteLine("--------------------------------------------------------------------------------------------------");
                sw.WriteLine(" Time              User ID       Terminal     Transactions                    Details             ");
                sw.WriteLine("--------------------------------------------------------------------------------------------------");
                // ---------- 12345678901234512345678901234512345678901234567890
                sw.WriteLine(sDetail.ToString());
                sw.Close();
            }
        }

        public string OpenFileConfig()
        {

            string TextLine = String.Empty;

            string AppPath = GetAppPath();

            string FILE_NAME = AppPath + "CONFIG.txt";

            if (System.IO.File.Exists(FILE_NAME) == true)
            {

                System.IO.StreamReader objReader = new System.IO.StreamReader(FILE_NAME);

                while (objReader.Peek() != -1)
                {
                    TextLine = TextLine + objReader.ReadLine();
                    break;
                }

                return TextLine.TrimEnd();
            }
            else
            {

                //MessageBox.Show("File Not Found", "File Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            return TextLine.TrimEnd();
        }

        public string GetDBName()
        {
            string xConnStr = OpenFileConfig();
            //Data Source=PNB1023D074\SQLEXPRESS;Initial Catalog=CPMData;Integrated Security=True
            string[] words = xConnStr.Split(';');
            xConnStr = words[1].ToString();
            string[] server = xConnStr.Split('=');
            return server[1].ToString();
        }

        public string GetServerName()
        {
            string xConnStr = OpenFileConfig();
            //Data Source=PNB1023D074\SQLEXPRESS;Initial Catalog=CPMData;Integrated Security=True
            string[] words = xConnStr.Split(';');
            xConnStr = words[0].ToString();
            string[] server = xConnStr.Split('=');
            return server[1].ToString();
        }

        public SqlConnection GetSqlConnectionSQLEX()  //SQL EXPRESS
        {

            string xConnStr2 = String.Empty;
            string xConnStr = String.Empty;
            xConnStr = OpenFileConfig();

            /*
            //Data Source = localhost; Initial Catalog = CTS2; Persist Security Info = False; Integrated Security = True; Connection Timeout = 45
            string[] conpara = xConnStr.Split(';');
            string DataBaseName1 = conpara[1].ToString();

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(OpenFileConfig());
            builder.ConnectionString = "Data Source = localhost;" + DataBaseName1;
            builder["Persist Security Info"] = false;
            builder["Integrated Security"] = true;
            builder["Connect Timeout"] = 60;
            */

            //Data Source = localhost; Initial Catalog = CTS1; Persist Security Info = False; Integrated Security = True; Connection Timeout = 45
            //string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["dbHPTIA"].ConnectionString;
            //xConnStr2 = connectionString; 
            xConnStr2 = "Data Source=.\\SQLEXPRESS;AttachDbFilename=" + xConnStr + ";Integrated Security=True;Connect Timeout=30";
            //Data Source=PNB1023D074;Initial Catalog="D:\PROJECTS\2015\RFS - DOLLAR PROMO\DATABASE\ATMSAFE_RAFFLE.MDF";Integrated Security=True;
            SqlConnection sqlCon = new SqlConnection(xConnStr);

            try
            {
                sqlCon.Open();

                return sqlCon;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            return sqlCon;

        }
        public SqlConnection GetSqlConnection()
        {

            string xConnStr2 = String.Empty;
            string xConnStr = String.Empty;
            xConnStr = OpenFileConfig();

            //CHECK IF SQLEXPRESS ON CONFIG.TXT

            if (xConnStr.Contains("SQLEXPRESS") == true)
            {
                xConnStr2 = "Data Source=.\\SQLEXPRESS;AttachDbFilename=" + xConnStr + ";Integrated Security=True;Connect Timeout=60";
                //Data Source=PNB1023D074;Initial Catalog="D:\PROJECTS\2015\RFS - DOLLAR PROMO\DATABASE\ATMSAFE_RAFFLE.MDF";Integrated Security=True;
                SqlConnection sqlCon = new SqlConnection(xConnStr);

                try
                {
                    sqlCon.Open();

                    return sqlCon;
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message, "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                return sqlCon;
            }
            else
            {


                string[] conpara = xConnStr.Split(';');
                string DataBaseName1 = conpara[1].ToString();


                //Data Source = localhost; Initial Catalog = CTS1; Persist Security Info = False; Integrated Security = True; Connection Timeout = 45
                //string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["dbHPTIA"].ConnectionString;
                //xConnStr2 = connectionString; 
                //xConnStr2 = "Data Source=.\\SQLEXPRESS;AttachDbFilename=" + xConnStr + ";Integrated Security=True;Connect Timeout=30";
                //Data Source=PNB1023D074;Initial Catalog="D:\PROJECTS\2015\RFS - DOLLAR PROMO\DATABASE\ATMSAFE_RAFFLE.MDF";Integrated Security=True;
                SqlConnection sqlCon = new SqlConnection(xConnStr);

                try
                {
                    sqlCon.Open();

                    return sqlCon;
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message, "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                return sqlCon;
            }
        }



    }
}

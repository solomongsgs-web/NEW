﻿using CTS_WEB.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;


namespace CTS_WEB.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }
        public DbSet<Settings> Settings { get; set; }
        public DbSet<Biller> Biller { get; set; }
        public DbSet<Configs> Configs { get; set; }

        public DbSet<UserPass> UserPass { get; set; }
        public DbSet<Branches_SI> Branches_SI { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder
                .Entity<Branches_SI>(eb =>
                {
                    eb.HasNoKey();
                });
        }
    }
}

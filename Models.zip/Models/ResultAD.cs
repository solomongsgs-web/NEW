﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CTS_WEB.Models
{
    public class ResultAD
    {
        private string strEmployeeID;
        private string strsAMAccountName;
        private string strSN;
        private string strGivenName;
        private string strInitial;
        private string strMail;
        private string strPhysicalDeliveryOfficeName;
        private string strDepartment;
        private string strUserPrincipalName;

        public string EmployeeID
        {
            get { return strEmployeeID; }
            set { strEmployeeID = value; }
        }

        public string sAMAccountName
        {
            get { return strsAMAccountName; }
            set { strsAMAccountName = value; }
        }

        public string SN
        {
            get { return strSN; }
            set { strSN = value; }
        }

        public string GivenName
        {
            get { return strGivenName; }
            set { strGivenName = value; }
        }

        public string Initial
        {
            get { return strInitial; }
            set { strInitial = value; }
        }

        public string Mail
        {
            get { return strMail; }
            set { strMail = value; }
        }

        public string PDON
        {
            get { return strPhysicalDeliveryOfficeName; }
            set { strPhysicalDeliveryOfficeName = value; }
        }

        public string Department
        {
            get { return strDepartment; }
            set { strDepartment = value; }
        }

        public string UserPrincipalName
        {
            get { return strUserPrincipalName; }
            set { strUserPrincipalName = value; }
        }

    }

    public class ResultADList
    {
        public List<ResultAD> ListResultAD
        {
            get;
            set;
        }
    }
}

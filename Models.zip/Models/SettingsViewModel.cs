﻿using System.ComponentModel.DataAnnotations;

namespace CTS_WEB.Models
{
    public class Settings
    {
        public int Id { get; set; }
        [Display(Name = "MFT Host IP")]
        public string? HostIP { get; set; }

        [Display(Name = "MFT Port")]
        public int Port { get; set; }
        [Display(Name = "MFT UserName")]
        public string? UserName { get; set; }

        [Display(Name = "MFT Password")]
        public string? Password { get; set; }

        [Display(Name = "MFT PKEY")]
        public string? PKey { get; set; }

        [Display(Name = "MFT PIV")]
        public string? PIV { get; set; }

        [Display(Name = "MFT SSHHostKeyFingerprint")]
        public string? FingerPrint { get; set; }

        [Display(Name = "RemoteReceivePath")]
        public string? RemoteMFTFilePath { get; set; }
        [Display(Name = "RemoteSendFilePath")]
        public string? RemoteMFTSendPath { get; set; }
        [Display(Name = "Local Download Path")]
        public string? DLFolder { get; set; }
        [Display(Name = "Local Upload Path")]
        public string? UPFolder { get; set; }
        [Display(Name = "Output Folder")]
        public string? OutputPath { get; set; }

        [Display(Name = "UAR MFT Host IP")]
        public string? UARHostIP { get; set; }
 
        [Display(Name = "UAR MFT UserName")]
        public string? UARUserName { get; set; }

        [Display(Name = "MFT Password")]
        public string? UARPassword { get; set; }

        [Display(Name = "MFT PKEY")]
        public string? UARPKey { get; set; }

        [Display(Name = "MFT PIV")]
        public string? UARPIV { get; set; }

        [Display(Name = "UAR Report Path")]
        public string? UARSendFolder { get; set; }
    }
}

﻿using Novell.Directory.Ldap;
using Microsoft.AspNetCore.Identity;
namespace CTS_WEB.Models
{
    public class ApplicationUser : IdentityUser
    {

        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? EmpId { get; set; }
        public string? RoleName { get; set; }
        public int UsernameChangeLimit { get; set; } = 10;
        public byte[]? ProfilePicture { get; set; }

    }

}

﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace CTS_WEB.Models
{
    [Keyless]
    public class Branches_SI
    {
        
        public decimal SEQ { get; set; }

        [Display(Name = "Branch Code")]
        public string? BRCODE{ get; set; }

        [Display(Name = "Branch Acro")]
        public string? BRACRO { get; set; }

        [Display(Name = "Region")]
        public string? REGION { get; set; }

        [Display(Name = "Branch Name")]
        public string? BRNAME { get; set; }

        [Display(Name = "New BRSTN")]
        public string? NEWBRSTN { get; set; }

        [Display(Name = "Old BRSTN")]
        public string? OLDBRSTN { get; set; }

        [Display(Name = "Area")]
        public string? AREA { get; set; }


        [Display(Name = "Old Name")]
        public string? OLDNAME { get; set; }

        [Display(Name = "Ordering")]
        public int? ORDERING { get; set; }
    }
}

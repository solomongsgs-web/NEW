﻿namespace CTS_WEB.Models
{
    public class SftpFileInfo
    {
        public string FileName { get; set; }
        public long FileSize { get; set; }
        public DateTime  LastModified { get; set; }
        public bool IsSelected { get; set; } // For the checkbox
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CTS_WEB.Models
{
    public class FileListViewModel
    {
        public string LocalPath { get; set; }
        public string OutputPath { get; set; }
        public List<SftpFileInfo> Folder1Files { get; set; }
        public List<SftpFileInfo> Folder2Files { get; set; }
        public IEnumerable<string> LocalFiles { get; set; }
       
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime EventDateTime { get; set; }
    }
}

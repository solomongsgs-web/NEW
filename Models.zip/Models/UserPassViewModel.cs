﻿using System.ComponentModel.DataAnnotations;
namespace CTS_WEB.Models
{
    public class UserPass
    {
        public int Id { get; set; }
        public string? EmpId { get; set; }
        public string? UserName { get; set; }

        public string? PASSWORD { get; set; }

        public string? PKEY { get; set; }

        public string? PIV { get; set; }
 
    }
}

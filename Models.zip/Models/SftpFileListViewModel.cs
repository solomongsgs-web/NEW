﻿using System.Collections.Generic;

namespace CTS_WEB.Models
{
    public class SftpFileListViewModel
    {
        public string RemotePath { get; set; }
        public string LocalPath { get; set; }
        public string OutputPath { get; set; }
        public List<SftpFileInfo> Files { get; set; }
        public IEnumerable<string> LocalFiles { get; set; }
        public IEnumerable<string> OutputFiles { get; set; }
    }
}

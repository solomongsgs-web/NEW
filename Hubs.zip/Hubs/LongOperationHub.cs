﻿using CTS_WEB.Data;
using CTS_WEB.Hubs;
using CTS_WEB.Models;
using CTS_WEB.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Microsoft.Identity.Client;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO.Compression;
using System.Runtime.ConstrainedExecution;
using System.Threading;
using System.Threading.Tasks;
using WinSCP;


namespace CTS_WEB.Hubs
{
    public class LongOperationHub : Hub
    {



        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private readonly IHubContext<LongOperationHub> _hubContext;

        public LongOperationHub(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context, IHubContext<LongOperationHub> hubContext)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
            _hubContext = hubContext;
        }



        //VARIABLES 

        int processFileCtr = 0;
        int generatedFileCtr = 0;
        bool blnDownload = false;
        string strWorkingFolder = string.Empty;
        public System.Data.DataTable tblBRANCH;
        public System.Data.DataTable tblDET;
        public System.Data.DataTable tblSORT;
        public string strNewFile;
        public string strOldFile;
        private string SOURCE_FOLDER;
        private string SOURCE_FILE;
        private string OUTPUT_FOLDER;
        private int LINECOUNT;
        public System.Data.DataTable SortedTable;

        private string NEW_FILE;

        private int PAGELINECOUNT;
        private int TOTALPAGE;
        private decimal decBRANCHAMOUNTTOTAL = 0;
        private decimal decPAGETOTAL = 0;
        private string[] Temp1 = new string[20000];
        private string[] Temp2 = new string[20000];
        private string[] Temp3 = new string[20000];
        private string[] Temp = new string[20000];
        private string[] Sort1 = new string[20000];
        private int iTOTALITEMS = 0;
        public double percentage = 0;
        public int totalFiles = 0;




#pragma warning disable CS8765 // Nullability of type of parameter doesn't match overridden member (possibly because of nullability attributes).
        public override Task OnDisconnectedAsync(Exception exception)
#pragma warning restore CS8765 // Nullability of type of parameter doesn't match overridden member (possibly because of nullability attributes).
        {
            //Clients.All.SendAsync(
            //    "ReceiveMessage",
            //    "system",
            //    $"{Context.ConnectionId} disconnected " + exception.Message);
            return base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task Start(string connectionId)
        {

            await LongOperationTask(connectionId);
        }

        public void SortArray(int ArrSize)
        {
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";
            //string convTAMT = "";
            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";
            string TextLine = string.Empty;
            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("RID");
            dt.Columns.Add("CHKNO");
            dt.Columns.Add("DRBRCH");
            dt.Columns.Add("ACCTNO");
            dt.Columns.Add("TCODE");
            dt.Columns.Add("TAMT");
            dt.Columns.Add("SERIES");
            dt.Columns.Add("BRSTN");
            dt.Columns.Add("FILLER");

            for (int ax = 0; ax <= ArrSize; ax++)
            {
                TextLine = Temp[ax].ToString();
                DataRow _ravi = dt.NewRow();
                RID = TextLine.Substring(0, 2);
                CHKNO = TextLine.Substring(2, 10);
                DRBRCH = TextLine.Substring(12, 9);
                ACCTNO = TextLine.Substring(21, 12);
                TCODE = TextLine.Substring(33, 3);
                TAMT = TextLine.Substring(36, 12);
                SERIES = TextLine.Substring(48, 6);
                BRSTN = TextLine.Substring(54, 5);
                FILLER = TextLine.Substring(59, 5);
                _ravi["RID"] = RID.Trim();
                _ravi["CHKNO"] = CHKNO.Trim();
                _ravi["DRBRCH"] = DRBRCH.Trim();
                _ravi["ACCTNO"] = ACCTNO.Trim();
                _ravi["TCODE"] = TCODE.Trim();
                _ravi["TAMT"] = TAMT.Trim();
                _ravi["SERIES"] = SERIES.Trim();
                _ravi["BRSTN"] = BRSTN.Trim();
                _ravi["FILLER"] = FILLER.Trim();
                dt.Rows.Add(_ravi);
            }

            dt.DefaultView.Sort = "ACCTNO, CHKNO";

            for (int bx = 0; bx < dt.Rows.Count; bx++)
            {
                TextLine = "";
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    TextLine = TextLine.Trim() + dt.Rows[bx][col].ToString().Trim();
                }
                Temp1[bx] = TextLine.Trim();
            }
        }
        public int READARRAYFILE(string[] ArrTEMP, int ArrSize)
        {
            //Number of Lines
            int LineCtr = 0;
            string AcctNo = "";
            string NextAcctNo = "";
            string PrevAcctNo = "";
            string strAmt = "";
            decimal dAmt = 0;
            int LenArray = ArrTEMP.Length;
            decimal dAmtTotal = 0;


            string detLine = string.Empty;
            string nexLine = string.Empty;
            int ItemCount = 0;
            if (ArrSize == 0)
            {
                //for (int x = 0; x < ArrSize; x++)
                // {
                detLine = ArrTEMP[0].ToString();
                AcctNo = detLine.Substring(21, 12);
                strAmt = detLine.Substring(36, 12);
                dAmt = Convert.ToDecimal(strAmt);
                dAmt = dAmt / 100;
                dAmtTotal = dAmtTotal + dAmt;

                if (NextAcctNo.Length > 0)
                {
                    if (AcctNo == NextAcctNo)  //SAME ACCTNO
                    {
                        LineCtr = LineCtr + 1;
                        ItemCount = ItemCount + 1;
                    }
                    else  //NEXT ACCTNO IS DIFFERENT 
                    {
                        //WRITE ACCOUNT TOTAL and TOTAL COUNT
                        if (ItemCount >= 1)
                        {
                            LineCtr = LineCtr + 1; //Item
                            LineCtr = LineCtr + 1; //Totals
                            ItemCount = ItemCount + 1;
                            LineCtr = LineCtr + 1; //SPACE
                            ItemCount = 0;
                        }
                        else
                        {
                            LineCtr = LineCtr + 1; //Item
                            LineCtr = LineCtr + 1; //SPACE
                        }
                        PrevAcctNo = AcctNo;
                    }
                }
                //}
            }
            else
            {
                for (int x = 0; x < ArrSize; x++)
                {
                    detLine = ArrTEMP[x].ToString();
                    AcctNo = detLine.Substring(21, 12);
                    strAmt = detLine.Substring(36, 12);
                    dAmt = Convert.ToDecimal(strAmt);
                    dAmt = dAmt / 100;
                    dAmtTotal = dAmtTotal + dAmt;
                    if (x == ArrSize - 1)
                    {
                        NextAcctNo = PrevAcctNo;
                    }
                    else
                    {
                        nexLine = ArrTEMP[x + 1].ToString(); //Check Next Line
                        NextAcctNo = nexLine.Substring(21, 12);
                    }
                    if (NextAcctNo.Length > 0)
                    {
                        if (AcctNo == NextAcctNo)  //SAME ACCTNO
                        {
                            LineCtr = LineCtr + 1;
                            ItemCount = ItemCount + 1;
                        }
                        else  //NEXT ACCTNO IS DIFFERENT 
                        {
                            //WRITE ACCOUNT TOTAL and TOTAL COUNT
                            if (ItemCount >= 1)
                            {
                                LineCtr = LineCtr + 1; //Item
                                LineCtr = LineCtr + 1; //Totals
                                ItemCount = ItemCount + 1;
                                LineCtr = LineCtr + 1; //SPACE
                                ItemCount = 0;
                            }
                            else
                            {
                                LineCtr = LineCtr + 1; //Item
                                LineCtr = LineCtr + 1; //SPACE
                            }
                            PrevAcctNo = AcctNo;
                        }
                    }
                    else
                    {
                        LineCtr = LineCtr + 1; //1 Item
                    }
                }
            }



            decBRANCHAMOUNTTOTAL = dAmtTotal;
            return LineCtr;


        }



        public int INSERTSPACETOFILE(string[] ArrTEMP, int ArrSize)
        {
            //Number of Lines
            int LineCtr = 0;
            string AcctNo = "";
            string NextAcctNo = "";
            string PrevAcctNo = "";
            string strAmt = "";
            decimal dAmt = 0;
            int LenArray = ArrTEMP.Length;
            decimal dAmtTotal = 0;
            decimal decACCTTOTAL = 0;
            string sRID = "";
            string sCHKNO = "";
            string sDRBRCH = "";
            string sACCTNO = "";
            string sTCODE = "";
            string sTAMT = "";
            string sconvTAMT = "";
            string sSERIES = "";
            string sBRSTN = "";
            string sFILLER = "";
            string detLine = string.Empty;
            string nexLine = string.Empty;
            string newLine = string.Empty;
            int ItemCount = 0;
            int iCtr = 0;
            InitArray2();

            for (int x = 0; x < ArrSize; x++)
            {
                detLine = ArrTEMP[x].ToString();

                sRID = detLine.Substring(0, 2);
                sCHKNO = detLine.Substring(2, 10);
                sDRBRCH = detLine.Substring(12, 9);
                sACCTNO = detLine.Substring(21, 12);
                sTCODE = detLine.Substring(33, 3);
                sTAMT = detLine.Substring(36, 12);
                sSERIES = detLine.Substring(48, 6);
                sBRSTN = detLine.Substring(54, 5);
                sFILLER = detLine.Substring(59, 5);

                AcctNo = detLine.Substring(21, 12);
                strAmt = detLine.Substring(36, 12);
                dAmt = Convert.ToDecimal(strAmt);
                dAmt = dAmt / 100;
                dAmtTotal = dAmtTotal + dAmt;
                sconvTAMT = dAmt.ToString("#,###,###,###,##0.00");
                if (x == ArrSize - 1)
                {
                    NextAcctNo = PrevAcctNo;
                }
                else
                {
                    nexLine = ArrTEMP[x + 1].ToString(); //Check Next Line
                    NextAcctNo = nexLine.Substring(21, 12);
                }

                if (NextAcctNo.Length > 0)
                {
                    if (AcctNo == NextAcctNo)  //SAME ACCTNO
                    {

                        //12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567
                        newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                        Temp2[iCtr] = newLine; //item
                        ItemCount = ItemCount + 1;  //counter  
                        decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals        
                        PrevAcctNo = AcctNo;
                        iCtr++;

                    }
                    else  //NEXT ACCTNO IS DIFFERENT 
                    {
                        //WRITE ACCOUNT TOTAL and TOTAL COUNT
                        if (ItemCount >= 1)
                        {
                            //12345678901234567890123456789012345678901234567890123
                            newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                            Temp2[iCtr] = newLine; //item
                            ItemCount = ItemCount + 1; //counter
                            iCtr++;
                            decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals       
                                                                 //12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
                            newLine = "                    " + "ACCOUNT TOTAL --> COUNT:" + ItemCount.ToString().PadLeft(8, ' ') + "  AMOUNT:     " + decACCTTOTAL.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
                            Temp2[iCtr] = newLine; //totals
                            iCtr++;
                            Temp2[iCtr] = "";
                            iCtr++;
                            ItemCount = 0;
                            decACCTTOTAL = 0;
                        }
                        else
                        {
                            //12345678901234567890123456789012345678901234567890123
                            newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                            Temp2[iCtr] = newLine; //item
                            iCtr++;
                            Temp2[iCtr] = "";
                            iCtr++;
                        }
                        PrevAcctNo = AcctNo;
                    }
                }
                else  //ONE ITEM ONLY 
                {
                    newLine = "                    " + sCHKNO.PadRight(16, ' ') + "          " + sACCTNO.PadRight(16, ' ') + "           " + sTCODE + sconvTAMT.PadLeft(20, ' ') + detLine.Substring(48, 14).PadLeft(27, ' ');
                    Temp2[iCtr] = newLine; //item
                    ItemCount = ItemCount + 1;  //counter  
                    decACCTTOTAL = decACCTTOTAL + dAmt;  //Totals        
                    PrevAcctNo = AcctNo;
                    iCtr++;
                }
            }
            return iCtr;
        }

        public void WRITEPAGE(int iStart, int iEnd, int iSize, string sBRNAME, string strBRSTN, string sDate, int iPAGECTR, int iTOTALPAGE, bool EndPage, string SOURCE_FOLDER)
        {
            int ItemSize = iSize;
            int itemCtr = 0;
            int NoRowSpace = 0;
            decimal dAMOUNT = 0;
            string sAMT = "";
            NoRowSpace = iSize % 50;
            if (NoRowSpace > 0)
            {
                NoRowSpace = 50 - NoRowSpace;
            }
            string TempLine = string.Empty;
            WriteHeader(sBRNAME, strBRSTN, sDate, iPAGECTR, iTOTALPAGE, SOURCE_FOLDER);
            PAGELINECOUNT = PAGELINECOUNT + 10;
            for (int ctr = iStart; ctr < iEnd; ctr++)
            {
                TempLine = Temp2[ctr].ToString();
                WriteToFile(SOURCE_FOLDER, strBRSTN, TempLine);
                PAGELINECOUNT = PAGELINECOUNT + 1;
                //Compute for Page Total
                if (TempLine.Trim().Length > 0)
                {
                    //string[] pdate = TempLine.Split(' ');
                    //sAMT = pdate[3].ToString();
                    if (TempLine.Contains("ACCOUNT TOTAL") == true)
                    {

                    }
                    else
                    {
                        sAMT = TempLine.Substring(82, 20);
                        sAMT = sAMT.Trim();
                        dAMOUNT = Convert.ToDecimal(sAMT);
                        decPAGETOTAL = decPAGETOTAL + dAMOUNT;
                        itemCtr++;
                    }
                }
            }//TEMP BRSTN FILE  For Loop
            if (NoRowSpace > 0)
            {
                for (int rep = 1; rep <= NoRowSpace; rep++)
                {
                    TempLine = "                                                                                                                                   ";
                    WriteToFile(SOURCE_FOLDER, strBRSTN, TempLine);
                    PAGELINECOUNT = PAGELINECOUNT + 1;
                }
            }

            if (EndPage == true)
            {
                WriteFooterTotal(sBRNAME, strBRSTN, itemCtr, iTOTALITEMS, decPAGETOTAL, decBRANCHAMOUNTTOTAL, SOURCE_FOLDER);
            }
            else
            {
                WriteFooter(sBRNAME, strBRSTN, itemCtr, iTOTALITEMS, decPAGETOTAL, decBRANCHAMOUNTTOTAL, SOURCE_FOLDER);
            }

        }
        public void WriteFooter(string BRNAME, string BRSTN, int iPage, int iPageTotal, decimal TotAmount, decimal BranchTotal, string SOURCE_FOLDER)
        {
            /*       
             _________________________________________________________________________________________________________________________________
            TO: PNB - MANILA - ESCOLTA                    BRSTN 01008 - 001           Page Count:       27         Page Amount:        5,232,095.64
            ACCUMULATED TOTALS FOR:                       BRSTN 01008 - 001          Total Count:       27        Total Amount:        5,232,095.64
            */
            string sDETAIL = string.Empty;
            //sDETAIL = "-----------------------------------------------------------------------------------------------------------------------------------";
            sDETAIL = "____________________________________________________________________________________________________________________________________________";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "TO: PNB - " + BRNAME.PadRight(34, ' ') + "BRSTN " + BRSTN + "          " + " Page Count:" + iPage.ToString().PadLeft(9, ' ') + "         " + "Page Amount:" + TotAmount.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            //sDETAIL = "ACCUMULATED TOTALS FOR:                     " + "BRSTN " + BRSTN + "          " + "Total Count:" + iPageTotal.ToString().PadLeft(9, ' ') + "        " + "Total Amount:" + BranchTotal.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            //WriteToFile(BRSTN, sDETAIL);
        }
        public void WriteFooterTotal(string BRNAME, string BRSTN, int iPage, int iPageTotal, decimal TotAmount, decimal BranchTotal, string SOURCE_FOLDER)
        {
            /*       
             _________________________________________________________________________________________________________________________________
            TO: PNB - MANILA - ESCOLTA                    BRSTN 01008 - 001           Page Count:       27         Page Amount:        5,232,095.64
            ACCUMULATED TOTALS FOR:                       BRSTN 01008 - 001          Total Count:       27        Total Amount:        5,232,095.64
            */
            string sDETAIL = string.Empty;
            //sDETAIL = "-----------------------------------------------------------------------------------------------------------------------------------";
            sDETAIL = "____________________________________________________________________________________________________________________________________________";
            //   ---------

            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "TO: PNB - " + BRNAME.PadRight(34, ' ') + "BRSTN " + BRSTN + "          " + " Page Count:" + iPage.ToString().PadLeft(9, ' ') + "         " + "Page Amount:" + TotAmount.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
            sDETAIL = "ACCUMULATED TOTALS FOR:                     " + "BRSTN " + BRSTN + "          " + "Total Count:" + iPageTotal.ToString().PadLeft(9, ' ') + "        " + "Total Amount:" + BranchTotal.ToString("#,###,###,###,##0.00").PadLeft(20, ' ');
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);
        }
        public void WriteToFile(string SOURCE_FOLDER, string Brstn, string strLine)
        {
            string NewFileName = string.Empty;
            string filePath = SOURCE_FOLDER + "\\" + Brstn + ".DET";

            NewFileName = filePath;
            if (!System.IO.File.Exists(NewFileName))
            {
                using (StreamWriter sw = System.IO.File.CreateText(NewFileName))
                {
                    sw.WriteLine(strLine);
                    sw.Close();
                }
            }
            else if (System.IO.File.Exists(NewFileName))
            {
                //TextWriter tw = new StreamWriter(NewFileName);
                //tw.WriteLine(TextLine);
                //tw.Close();
                using (StreamWriter w = System.IO.File.AppendText(NewFileName))
                {
                    w.WriteLine(strLine);
                }
            }
        }

        public void WriteHeader(string BRNAME, string BRSTN, string sDate, int iPage, int iPTotal, string SOURCE_FOLDER)
        {
            string sDETAIL = string.Empty;
            string newBRSTN = BRSTN.Substring(0, 5) + "-" + BRSTN.Substring(5, 3);
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //1
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //2
                                                        //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            sDETAIL = "DATE : " + sDate + "                  CICS Detail List of Branch Inward Regular Clearing Items                " + "PAGE : " + iPage.ToString().PadLeft(7, ' ') + " of " + iPTotal.ToString();
            //1234567     890123456789      0123456789012345678901234567890123456789012345678901234567890  12345678901234567890123456789012345678901234567890
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL);  //3
            //sDETAIL = "                                                " + "GREATER MANILA ELECTRONIC CLEARING SYSTEM";
            //WriteToFile(BRSTN, sDETAIL);
            //sDETAIL = " ";
            //WriteToFile(BRSTN, sDETAIL);
            //sDETAIL = "                                       CICS Detail List of Branch Inward Regular Clearing Items";
            //WriteToFile(BRSTN, sDETAIL);
            sDETAIL = "                                  To: " + "PNB - " + BRNAME.PadRight(35, ' ') + "BRSTN " + newBRSTN;
            //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            //CALOOCAN-SANGANDAAN               BRSTN 01008-003
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //4  
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //5
            sDETAIL = " ";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //6   1234567890 
                                                        //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345
            sDETAIL = "                    Cheque No.                  Account No.               TC              Amount              Sender's BIN";
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //7
            sDETAIL = "--------------------------------------------------------------------------------------------------------------------------------------------";  //---------
            WriteToFile(SOURCE_FOLDER, BRSTN, sDETAIL); //8
        }



        public void InitArray()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp[x] = "";
            }
        }
        public void InitArray1()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp1[x] = "";
            }
        }
        public void InitArray2()
        {
            for (int x = 0; x < 20000; x++)
            {
                Temp2[x] = "";
            }
        }
        public string GetYear(string strDate)
        {
            string strYear = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strYear = strYY;
            return strYear;
        }
        public string GetMonthFolder(string strDate)
        {
            string strMonth = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            string sDate = strYY + strMM + strDD;
            string newDate = string.Empty;
            //20201210
            strDD = sDate.Substring(6, 2).ToString();
            strMM = sDate.Substring(4, 2).ToString();
            strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            return newDate;
        }
        public string GetDateMMDDYY(string strDate)
        {
            string strNewDate = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strNewDate = strMM + strDD + strYY;
            return strNewDate;
        }


        public int ReadFileCountLines(string sFileName)
        {
            string TextLine = string.Empty;
            string TempLine = string.Empty;
            string NewLine = string.Empty;
            string NextLine = string.Empty;
            string sDate = string.Empty;
            string sDetail = string.Empty;
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";

            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";

            string strBRSTN = "";
            string strTotalItemsBranch = "";
            int TotalItemsPerBranch = 0;
            int TempCtr = 0;
            int xctr = 0;

            int LCTR = 0;
            if (System.IO.File.Exists(sFileName) == true)
            {

                System.IO.StreamReader objReader = new System.IO.StreamReader(sFileName);

                while (objReader.Peek() != -1)
                {
                    TextLine = objReader.ReadLine();
                    if (TextLine.ToString().Trim().Length > 0)
                    {
                        RID = TextLine.Substring(0, 2);
                        CHKNO = TextLine.Substring(2, 10);
                        DRBRCH = TextLine.Substring(12, 9);
                        ACCTNO = TextLine.Substring(21, 12);
                        TCODE = TextLine.Substring(33, 3);
                        TAMT = TextLine.Substring(36, 12);
                        SERIES = TextLine.Substring(48, 6);
                        BRSTN = TextLine.Substring(54, 5);
                        FILLER = TextLine.Substring(59, 5);
                        xctr = xctr + 1;
                    }
                    LCTR++;
                }
                objReader.Close();
            }
            else
            {
                //MessageBox.Show("File Not Found", "File Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            LCTR = xctr;
            return xctr;
        }

        public void MoveSplittedFiles()
        {
            string LocalDownloadPath = "det_uploads";
            string OutputFilePath = "det_converted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // MOVE FILES
            string myDate = DateTime.Now.ToShortDateString();
            string[] pdate = myDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            string sDate = strYY + strMM + strDD;
            string newDate = string.Empty;
            //20201210
            strDD = sDate.Substring(6, 2).ToString();
            strMM = sDate.Substring(4, 2).ToString();
            strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            string MonthFolder = newDate;
            MonthFolder = MonthFolder + " " + strYY;


            string strSplittedPath = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strMM + strDD + strYY;
            // Get files from Folder 2
            if (Directory.Exists(strSplittedPath))
            {
                string[] filePaths = Directory.GetFiles(strSplittedPath);
                List<SftpFileInfo> files = new List<SftpFileInfo>();

                int count = filePaths.Length;
                if (count > 0)
                {

                    foreach (string filePath in filePaths)
                    {
                        // Handles the file download request
                        if (string.IsNullOrEmpty(filePath.ToString()))
                        {
                            //return BadRequest("File name is required.");
                        }
                        try
                        {
                            //Get File and Move
                            string strFileName = filePath.ToString();
                            if (strFileName.Length > 0)
                            {
                                string[] words = strFileName.Split("\\");

                                if (words[4].ToString().Contains("DET") == true)
                                {
                                    var DestinationPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                                    string TargetFilePath = DestinationPath + "\\" + words[4];
                                    System.IO.File.Move(strFileName, TargetFilePath);
                                }
                                else
                                {
                                    System.IO.File.Delete(strFileName);
                                }
                            }
                        }
                        catch
                        { }
                    }
                }
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
            }
        }

        public void DownloadFolderAsZip()
        {
            var sourceFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted"); // e.g., "wwwroot/YourFolderName"
            var zipFileName = $"DET_Archive-{DateTime.Now.ToString("yyyy-MM-dd")}.zip";

            var zipPath = Path.Combine(Path.GetTempPath(), zipFileName); // Create the zip in a temp path

            // Ensure the source folder exists
            if (!Directory.Exists(sourceFolderPath))
            {
                //return NotFound("Source folder not found.");
            }

            try
            {
                // Create the zip file from the directory
                ZipFile.CreateFromDirectory(sourceFolderPath, zipPath, CompressionLevel.Fastest, true);

                // Return the created zip file for download
                File(bytes: System.IO.File.ReadAllBytes(zipPath), "application/zip", zipFileName);

            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                //return BadRequest($"Error zipping folder: {ex.Message}");
            }
            finally
            {
                // Clean up the temporary zip file after it's been sent
                if (System.IO.File.Exists(zipPath))
                {
                    var DestFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                    DestFolderPath = DestFolderPath + "\\" + zipFileName;
                    System.IO.File.Move(zipPath, DestFolderPath);
                    System.IO.File.Delete(zipPath);

                    //Delete all DET files except ZIP
                    DestFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                    // Get files from Folder 2
                    if (Directory.Exists(DestFolderPath))
                    {
                        string[] filePaths3 = Directory.GetFiles(DestFolderPath);
                        List<SftpFileInfo> files = new List<SftpFileInfo>();

                        foreach (string filePath3 in filePaths3)
                        {
                            //Get File and Move
                            string sFileName = filePath3.ToString();
                            if (sFileName.Length > 0)
                            {

                                if (sFileName.ToString().Contains(".DET") == true)
                                {
                                    System.IO.File.Delete(sFileName);
                                }
                            }
                        }
                    }
                    //Clean and Delete Working Folder
                    if (Directory.Exists(strWorkingFolder))
                    {
                        Directory.Delete(strWorkingFolder, recursive: true);
                        string WFolder = "C:\\PCHC REPORTS";
                        if (Directory.Exists(WFolder))
                        {
                            Directory.Delete(WFolder, recursive: true);
                        }
                    }


                }
            }

        }

        private IActionResult BadRequest(string v)
        {
            throw new NotImplementedException();
        }

        private IActionResult NotFound(string v)
        {
            throw new NotImplementedException();
        }

        private void File(byte[] bytes, string v, string zipFileName)
        {
            throw new NotImplementedException();
        }


        //LONG OPERATION TASK 
        //simulate a long task
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
        private async Task LongOperationTask(string connectionId)
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously
        {

            clsBranch Branch = new clsBranch();

            System.Data.DataTable tblBRANCH = Branch.CreateTableBRANCH();

            var Branchlist = _context.Branches_SI.ToList();
            for (int x = 0; x < Branchlist.Count; x++)
            {
                System.Data.DataRow newRow = tblBRANCH.NewRow();

                newRow["SEQ"] = Convert.ToDecimal(Branchlist[x].SEQ);
                newRow["BRCODE"] = Branchlist[x].BRCODE;
                newRow["BRACRO"] = Branchlist[x].BRACRO;
                newRow["REGION"] = Branchlist[x].REGION;
                newRow["BRNAME"] = Branchlist[x].BRNAME;
                newRow["NEWBRSTN"] = Branchlist[x].NEWBRSTN;
                newRow["OLDBRSTN"] = Branchlist[x].OLDBRSTN;
                newRow["AREA"] = Branchlist[x].AREA;
                newRow["OLDNAME"] = Branchlist[x].OLDNAME;
                newRow["ORDERING"] = Convert.ToInt64(Branchlist[x].ORDERING);

                tblBRANCH.Rows.Add(newRow);

            }
            //USE LIST for Searching 
            List<clsBranch> listBranch = new List<clsBranch>();
            foreach (DataRow row in tblBRANCH.Rows)
            {
                clsBranch branch = new clsBranch
                {
                    Id = (double)row["SEQ"],
                    Brstn = row["NEWBRSTN"].ToString(),
                    BranchName = row["BRNAME"].ToString()
                };
                listBranch.Add(branch);
            }
            var multiSortedBranch = listBranch.OrderBy(emp => emp.Brstn).ToList();
            DateTime start = DateTime.UtcNow;
            string myDate = DateTime.Now.ToShortDateString();
            string sDate = Branch.GetDateString(myDate);
            string MonthFolder = Branch.ConvMonth(sDate);
            string strDate = Branch.GetDateMMDDYY(myDate);
            string strYY = Branch.GetYear(myDate).ToString();
            MonthFolder = MonthFolder + " " + strYY;

            string strNewFile = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString() + "\\01008000.MTF";
            int FileCtr = Branch.ReadFileCountBRSTN(strNewFile);

            int maxCount = FileCtr;
            //*** Start Splitting
            //START SPLIT 
            string TextLine = string.Empty;
            string TempLine = string.Empty;
            string NewLine = string.Empty;
            string NextLine = string.Empty;
            string RID = "";
            string CHKNO = "";
            string DRBRCH = "";
            string ACCTNO = "";
            string TCODE = "";
            string TAMT = "";
            string SERIES = "";
            string BRSTN = "";
            string FILLER = "";
            string strBRSTN = "";
            string sBRSTN = "";//formatted BRSTN
            sDate = "";
            string strTotalItemsBranch = "";
            int TotalItemsPerBranch = 0;
            int TempCtr = 0;
            string sBRNAME = "";
            int PAGECTR = 1;
            int iTOTALPAGECTR = 0;
            decimal TOTALPAGECTR = 0;
            int FILECTR = 0;
            myDate = DateTime.Now.ToShortDateString();

            MonthFolder = GetMonthFolder(myDate);
            strYY = GetYear(myDate).ToString();
            MonthFolder = MonthFolder + " " + strYY;
            strDate = GetDateMMDDYY(myDate);

            string strSourceNewPath = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString() + "\\01008000.MTF";

            strNewFile = strSourceNewPath;
            SOURCE_FOLDER = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString();
            //START GET BRANCH RECORDS
            //clsBranch Branch = new clsBranch();
            int iTotalLines = ReadFileCountLines(strNewFile);
            //Start Threading
            maxCount = iTotalLines; int xctr = 0;
            _ = System.Threading.Tasks.Task.Run(async () =>
            {
                if (System.IO.File.Exists(strNewFile) == true)
                {
                    System.IO.StreamReader objReader = new System.IO.StreamReader(strNewFile);
                    for (int i = 0; i < maxCount; i++)
                    {
                        TextLine = objReader.ReadLine();
                        if (TextLine.ToString().Trim().Length > 0)
                        {
                            RID = TextLine.Substring(0, 2);
                            CHKNO = TextLine.Substring(2, 10);
                            DRBRCH = TextLine.Substring(12, 9);
                            ACCTNO = TextLine.Substring(21, 12);
                            TCODE = TextLine.Substring(33, 3);
                            TAMT = TextLine.Substring(36, 12);
                            SERIES = TextLine.Substring(48, 6);
                            BRSTN = TextLine.Substring(54, 5);
                            FILLER = TextLine.Substring(59, 5);
                            xctr = xctr + 1;
                            if (RID == "BF")
                            {
                                //Get Date
                                sDate = TextLine.Substring(2, 8);
                                //Convert Date
                                sDate = Branch.ConvDate(sDate);
                            }
                            else
                            {
                                //DETAILS
                                if (RID == "01")
                                {
                                    Temp[TempCtr] = TextLine;
                                    TempCtr = TempCtr + 1;
                                }

                                if (RID == "BR")
                                {
                                    //SORT THE RECORDS
                                    //Pass Temp array to SORT
                                    SortArray(TempCtr - 1);
                                    strBRSTN = TextLine.Substring(2, 8);
                                    if (strBRSTN == "01008289")
                                        strBRSTN = strBRSTN + "";

                                    int LineCount = READARRAYFILE(Temp1, TempCtr);
                                    decimal decLineCount = Convert.ToDecimal(LineCount);
                                    decimal divisor = 50;
                                    decimal dTOTALPAGECTR = decLineCount / divisor;
                                    decimal dRem = Decimal.Remainder(decLineCount, divisor);
                                    dTOTALPAGECTR = Decimal.Divide(decLineCount, divisor);

                                    TOTALPAGECTR = dTOTALPAGECTR;
                                    if (TOTALPAGECTR < 1)
                                    {
                                        TOTALPAGECTR = 1;
                                        iTOTALPAGECTR = Convert.ToInt32(TOTALPAGECTR);
                                        TOTALPAGE = iTOTALPAGECTR;
                                    }
                                    else
                                    {
                                        TOTALPAGECTR = Decimal.Truncate(TOTALPAGECTR);
                                        iTOTALPAGECTR = Convert.ToInt32(TOTALPAGECTR);
                                        if (dRem > 0)
                                        {
                                            iTOTALPAGECTR = iTOTALPAGECTR + 1;
                                            TOTALPAGE = iTOTALPAGECTR;
                                        }

                                    }

                                    int Temp2Size = INSERTSPACETOFILE(Temp1, TempCtr);

                                    for (int x = 0; x < Temp2Size; x++)
                                    {
                                        string sData = Temp2[x].ToString();
                                    }
                                    //CREATE THE FILE 
                                    PAGECTR = 1;
                                    strBRSTN = TextLine.Substring(2, 8);
                                    if (strBRSTN == "05008003")
                                        strBRSTN = strBRSTN + "";
                                    strTotalItemsBranch = TextLine.Substring(11, 7);
                                    TotalItemsPerBranch = Convert.ToInt32(strTotalItemsBranch);
                                    iTOTALITEMS = TotalItemsPerBranch;

                                    sBRSTN = strBRSTN.Substring(0, 5) + "-" + strBRSTN.Substring(5, 3);

                                    var matchingBRSTN = multiSortedBranch.Where(p => p.Brstn.Contains(sBRSTN)).ToList();

                                    if (matchingBRSTN.Count > 0)
                                        sBRNAME = matchingBRSTN[0].BranchName.ToString();
                                    else
                                        sBRNAME = "";

                                    NEW_FILE = SOURCE_FOLDER + "\\" + strBRSTN + ".DET";
                                    FILECTR++;

                                    TempCtr = 0;

                                    if (Temp2Size <= 50)
                                        iTOTALPAGECTR = 1;

                                    //CHECK HOW MANY FILES
                                    if (iTOTALPAGECTR == 1)
                                    {
                                        if (Temp2Size == 1)
                                        {
                                            WRITEPAGE(0, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                            InitArray();
                                            InitArray1();
                                            InitArray2();
                                            TempCtr = 0;
                                            decPAGETOTAL = 0;
                                        }
                                        if (Temp2Size <= 50)
                                        {
                                            WRITEPAGE(0, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                            InitArray();
                                            InitArray1();
                                            InitArray2();
                                            TempCtr = 0;
                                            decPAGETOTAL = 0;
                                        }
                                        else
                                        {
                                            WRITEPAGE(0, Temp2Size - 1, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                            InitArray();
                                            InitArray1();
                                            InitArray2();
                                            TempCtr = 0;
                                            decPAGETOTAL = 0;
                                        }
                                    }
                                    else  //MORE THAN ONE PAGE
                                    {
                                        if (iTOTALPAGECTR == 2)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 100))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 3)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 150))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 4)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 200))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 5)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 250))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 6)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 300))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 7)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 350))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 8)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 400))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 9)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 450))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 10)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 500))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 11)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 550))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 12)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 600))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 13)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 650))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 14)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 700))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 15)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 750))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 16)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 800))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 17)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 850))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 18)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 900))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;


                                            }
                                        }

                                        if (iTOTALPAGECTR == 19)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 950))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 20)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1000))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 21)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1050))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;

                                            }
                                        }
                                        if (iTOTALPAGECTR == 22)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1100))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 23)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1150))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 24)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1200))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 25)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1250))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 26)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1300))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 27)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1350))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 28)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1400))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 29)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1450))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 30)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1500))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 31)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1550))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 32)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1600))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 33)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1650))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 34)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1700))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 35)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1750))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 36)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1800))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }

                                        if (iTOTALPAGECTR == 37)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1850))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;

                                            }
                                        }

                                        if (iTOTALPAGECTR == 38)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1900))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 39)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 1950))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 41)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2050))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 42)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2100))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 43)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2150))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 44)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2200))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 45)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2250))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;

                                            }
                                        }
                                        if (iTOTALPAGECTR == 46)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2300))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, 2250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //46th
                                                PAGECTR++;
                                                WRITEPAGE(2250, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        if (iTOTALPAGECTR == 47)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2350))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, 2250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //46th
                                                PAGECTR++;
                                                WRITEPAGE(2250, 2300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //47th
                                                PAGECTR++;
                                                WRITEPAGE(2300, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        //48th
                                        if (iTOTALPAGECTR == 48)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2400))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, 2250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //46th
                                                PAGECTR++;
                                                WRITEPAGE(2250, 2300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //47th
                                                PAGECTR++;
                                                WRITEPAGE(2300, 2350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //48th
                                                PAGECTR++;
                                                WRITEPAGE(2350, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        //49th
                                        if (iTOTALPAGECTR == 49)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2450))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, 2250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //46th
                                                PAGECTR++;
                                                WRITEPAGE(2250, 2300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //47th
                                                PAGECTR++;
                                                WRITEPAGE(2300, 2350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //48th
                                                PAGECTR++;
                                                WRITEPAGE(2350, 2400, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //49th
                                                PAGECTR++;
                                                WRITEPAGE(2400, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                        //50th
                                        if (iTOTALPAGECTR == 50)
                                        {
                                            if ((Temp2Size > 50) && (Temp2Size <= 2500))
                                            {
                                                //1st Page 
                                                WRITEPAGE(0, 50, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //2nd Page
                                                PAGECTR++;
                                                WRITEPAGE(50, 100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //3rd Page
                                                PAGECTR++;
                                                WRITEPAGE(100, 150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //4th Page
                                                PAGECTR++;
                                                WRITEPAGE(150, 200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //5th Page
                                                PAGECTR++;
                                                WRITEPAGE(200, 250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //6th Page
                                                PAGECTR++;
                                                WRITEPAGE(250, 300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //7th Page
                                                PAGECTR++;
                                                WRITEPAGE(300, 350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //8th Page
                                                PAGECTR++;
                                                WRITEPAGE(350, 400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //9th Page
                                                PAGECTR++;
                                                WRITEPAGE(400, 450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //10th Page
                                                PAGECTR++;
                                                WRITEPAGE(450, 500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //11th Page
                                                PAGECTR++;
                                                WRITEPAGE(500, 550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //12th Page 
                                                PAGECTR++;
                                                WRITEPAGE(550, 600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //13th Page
                                                PAGECTR++;
                                                WRITEPAGE(600, 650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //14th Page
                                                PAGECTR++;
                                                WRITEPAGE(650, 700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //15th Page
                                                PAGECTR++;
                                                WRITEPAGE(700, 750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //16th Page
                                                PAGECTR++;
                                                WRITEPAGE(750, 800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //17th Page
                                                PAGECTR++;
                                                WRITEPAGE(800, 850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //18th Page
                                                PAGECTR++;
                                                WRITEPAGE(850, 900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //19th Page
                                                PAGECTR++;
                                                WRITEPAGE(900, 950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //20th Page
                                                PAGECTR++;
                                                WRITEPAGE(950, 1000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //21st Page
                                                PAGECTR++;
                                                WRITEPAGE(1000, 1050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //22nd Page
                                                PAGECTR++;
                                                WRITEPAGE(1050, 1100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //23rd Page
                                                PAGECTR++;
                                                WRITEPAGE(1100, 1150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //24th
                                                PAGECTR++;
                                                WRITEPAGE(1150, 1200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //25th
                                                PAGECTR++;
                                                WRITEPAGE(1200, 1250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //26th
                                                PAGECTR++;
                                                WRITEPAGE(1250, 1300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //27th
                                                PAGECTR++;
                                                WRITEPAGE(1300, 1350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //28th
                                                PAGECTR++;
                                                WRITEPAGE(1350, 1400, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //29th
                                                PAGECTR++;
                                                WRITEPAGE(1400, 1450, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //30th
                                                PAGECTR++;
                                                WRITEPAGE(1450, 1500, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //31st
                                                PAGECTR++;
                                                WRITEPAGE(1500, 1550, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //32nd
                                                PAGECTR++;
                                                WRITEPAGE(1550, 1600, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //33rd
                                                PAGECTR++;
                                                WRITEPAGE(1600, 1650, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //34th
                                                PAGECTR++;
                                                WRITEPAGE(1650, 1700, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //35th
                                                PAGECTR++;
                                                WRITEPAGE(1700, 1750, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //36th
                                                PAGECTR++;
                                                WRITEPAGE(1750, 1800, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //37th
                                                PAGECTR++;
                                                WRITEPAGE(1800, 1850, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //38th
                                                PAGECTR++;
                                                WRITEPAGE(1850, 1900, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //39th
                                                PAGECTR++;
                                                WRITEPAGE(1900, 1950, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //40th
                                                PAGECTR++;
                                                WRITEPAGE(1950, 2000, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //41st
                                                PAGECTR++;
                                                WRITEPAGE(2000, 2050, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //42nd
                                                PAGECTR++;
                                                WRITEPAGE(2050, 2100, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //43rd
                                                PAGECTR++;
                                                WRITEPAGE(2100, 2150, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //44th
                                                PAGECTR++;
                                                WRITEPAGE(2150, 2200, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //45th
                                                PAGECTR++;
                                                WRITEPAGE(2200, 2250, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //46th
                                                PAGECTR++;
                                                WRITEPAGE(2250, 2300, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //47th
                                                PAGECTR++;
                                                WRITEPAGE(2300, 2350, 50, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //48th
                                                PAGECTR++;
                                                WRITEPAGE(2350, 2400, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //49th
                                                PAGECTR++;
                                                WRITEPAGE(2400, 2450, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, false, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                                //50th
                                                PAGECTR++;
                                                WRITEPAGE(2450, Temp2Size, Temp2Size, sBRNAME, strBRSTN, sDate, PAGECTR, iTOTALPAGECTR, true, SOURCE_FOLDER);
                                                decPAGETOTAL = 0;
                                            }
                                        }
                                    }
                                    //DisplayInput(NEW_FILE, FILECTR);
                                    InitArray();
                                    InitArray1();
                                    InitArray2();
                                    TempCtr = 0;
                                    decPAGETOTAL = 0;
                                    PAGECTR = 1;
                                    iTOTALPAGECTR = 0;
                                    TOTALPAGECTR = 0;
                                } //End if BR
                            } //else
                        }
                        //Thread.Sleep(10);

                        TimeSpan duration = DateTime.UtcNow - start;
                        await _hubContext.Clients.Client(connectionId).SendAsync("ReportProgress", duration.ToString("g"), i * 100 / (maxCount - 1)).ConfigureAwait(false);
                    }
                    objReader.Close();

                    MoveSplittedFiles();

                    DownloadFolderAsZip();

                    await _hubContext.Clients.Client(connectionId).SendAsync("ReportFinish").ConfigureAwait(false);

                }


            });



        }

    }
}
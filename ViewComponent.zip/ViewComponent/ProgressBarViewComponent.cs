﻿using Microsoft.AspNetCore.Mvc;

namespace CTS_WEB.ViewComponent
{
    public class ProgressBarViewComponent : Microsoft.AspNetCore.Mvc.ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}

﻿namespace System.Web
{
    internal class HttpContext
    {
        internal static object Current;
    }
}
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CTS_WEB.Views.UserRoles
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

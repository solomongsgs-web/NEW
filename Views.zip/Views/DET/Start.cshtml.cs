using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CTS_WEB.Views.DET
{
    public class StartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CTS_WEB.Views.MST
{
    public class StartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

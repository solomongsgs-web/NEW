using CTS_WEB.Models;
using CTS_WEB.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CTS_WEB.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SftpService _sftpService;
        public HomeController(ILogger<HomeController> logger, SftpService sftpService)
        {
            _logger = logger;
            _sftpService = sftpService;
        }
        /// <
        /// TESTING SFTP Connectivity 
        public IActionResult TestSftp()
        {
            string host = "your_sftp_host";
            string user = "your_sftp_username";
            string pass = "your_sftp_password";
            // Optional: Get this from WinSCP client when connecting manually
            string fingerprint = "ssh-rsa 2048 xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx";

            bool connectionSuccessful = _sftpService.TestSftpConnection(host, user, pass, fingerprint);

            if (connectionSuccessful)
            {
                ViewBag.Message = "MFT Server connection successful!";
            }
            else
            {
                ViewBag.Message = "MFT Server connection failed.";
            }

            return View();
        }
        public IActionResult TestSftpConnection()
        {
            var isConnected = _sftpService.TestConnection();
            ViewBag.Message = isConnected
                ? "MFT connection was successful!"
                : "MFT connection failed. Check logs for details.";

            _logger.LogInformation("TestSftpConnection action executed. Connection status: {Status}", isConnected);
            if (TempData["AlertMessage"] != null)
            {
                ViewBag.Message = TempData["AlertMessage"];  // Pass to the view
            }
            return View();
        }

        public IActionResult Index()
        {
            if (TempData["AlertMessage"] != null)
            {
                ViewBag.Message = TempData["AlertMessage"];  // Pass to the view
            }
            return View();
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }


}

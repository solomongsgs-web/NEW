﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO.Compression;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;
using System.Threading.Tasks;
using WinSCP;
using CTS_WEB.Services;
using CTS_WEB.Data;
using CTS_WEB.Models;
using CTS_WEB.Hubs;
using Microsoft.AspNetCore.Authorization;


namespace CTS_WEB.Controllers
{
    [Authorize(Roles = "OCRMS_User,SuperAdmin")]
    public class OCRMSController : Controller
    {
     
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private readonly IHubContext<LongOperationHub> _hubContext;
        private readonly ILogger<OCRMSController> _logger;

        public OCRMSController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context, IHubContext<LongOperationHub> hubContext, ILogger<OCRMSController> logger)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
            _hubContext = hubContext;
            _logger = logger;
        }


        [HttpGet("download-multiple-filesOCRMS")]
        public async Task<IActionResult> Index()
        {

            
            // 1. Define the files you want to include (e.g., from a database or file system)
            var filesToZip = new List<string>
        {
            Path.Combine(_hostingEnvironment.WebRootPath, "files/OCRMS.exe"),
            Path.Combine(_hostingEnvironment.WebRootPath, "files/OCRMS_README.txt"),
            Path.Combine(_hostingEnvironment.WebRootPath, "files/CONFIG.txt"),
            Path.Combine(_hostingEnvironment.WebRootPath, "files/clsIonicZip.dll"),
            Path.Combine(_hostingEnvironment.WebRootPath, "files/IonicZip.dll") 
        };

            var zipName = $"Download-OCRMS.zip";     //{DateTime.Now.ToString("yyyy-MM-dd")}.zip";

            // 2. Create a memory stream to hold the zip file data
            using (var memoryStream = new MemoryStream())
            {
                // 3. Create a ZipArchive in create mode
                using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                {
                    // 4. Add each file to the zip archive
                    foreach (var file in filesToZip)
                    {
                        if (System.IO.File.Exists(file))
                        {
                            var entryName = Path.GetFileName(file); // Get just the file name
                            var entry = archive.CreateEntry(entryName, CompressionLevel.Fastest);

                            using (var entryStream = entry.Open())
                            using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                            {
                                await fileStream.CopyToAsync(entryStream);
                            }
                        }
                    }
                }

                // 5. Reset the memory stream position to the beginning before returning
                memoryStream.Seek(0, SeekOrigin.Begin);


                ViewBag.Message = "Files downloaded successfully";

                // 6. Return the file as a downloadable attachment
                return File(
                    fileContents: memoryStream.ToArray(), // Convert to array for simple return
                    contentType: "application/zip",
                    fileDownloadName: zipName
                );
            }
        }


    }
}

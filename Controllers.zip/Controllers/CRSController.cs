﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.IO.Pipes;
using System.Net.Http;
using System.Net.Mime;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
 


namespace CTS_WEB.Controllers
{
    [Authorize(Roles = "CRS_User,SuperAdmin")]
    public class CRSController : Controller
    {

        // Inject IWebHostEnvironment to get the web root path
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly ILogger<CRSController> _logger;

        public CRSController(IWebHostEnvironment hostingEnvironment, ILogger<CRSController> logger)
        {
            _hostingEnvironment = hostingEnvironment;
            _logger = logger;
        }


 

        [HttpGet("download-multiple-filesCRS")]
        public async Task<IActionResult> Index()
        {
            // 1. Define the files you want to include (e.g., from a database or file system)
            var filesToZip = new List<string>
        {
            Path.Combine(_hostingEnvironment.WebRootPath, "files/CRS_WEB.exe"),
            Path.Combine(_hostingEnvironment.WebRootPath, "files/CRS_README.txt")
        };

            var zipName = $"Download-CRS.zip";     //{DateTime.Now.ToString("yyyy-MM-dd")}.zip";

            // 2. Create a memory stream to hold the zip file data
            using (var memoryStream = new MemoryStream())
            {
                // 3. Create a ZipArchive in create mode
                using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                {
                    // 4. Add each file to the zip archive
                    foreach (var file in filesToZip)
                    {
                        if (System.IO.File.Exists(file))
                        {
                            var entryName = Path.GetFileName(file); // Get just the file name
                            var entry = archive.CreateEntry(entryName, CompressionLevel.Fastest);

                            using (var entryStream = entry.Open())
                            using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                            {
                                await fileStream.CopyToAsync(entryStream);
                            }
                        }
                    }
                }

                // 5. Reset the memory stream position to the beginning before returning
                memoryStream.Seek(0, SeekOrigin.Begin);


                ViewBag.Message = "Files downloaded successfully";

                // 6. Return the file as a downloadable attachment
                return File(
                    fileContents: memoryStream.ToArray(), // Convert to array for simple return
                    contentType: "application/zip",
                    fileDownloadName: zipName
                );
            }
        }

    }
}

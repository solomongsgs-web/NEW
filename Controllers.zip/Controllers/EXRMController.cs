﻿using CTS_WEB.Data;
using CTS_WEB.Hubs;
using CTS_WEB.Models;
using CTS_WEB.Services;
 
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;
using System.Threading.Tasks;
using WinSCP;

namespace CTS_WEB.Controllers
{
    [Authorize(Roles = "EXRM_Processor,EXRM_Consolidator,SuperAdmin")]
    public class EXRMController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<EXRMController> _logger;

        public EXRMController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context, UserManager<ApplicationUser> userManager, ILogger<EXRMController> logger)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }


        [HttpGet("download-multiple-filesEXRM")]
        public async Task<IActionResult> Index()
        {
            string username = User.Identity.Name;
            var memoryStream2 = new MemoryStream();

            //CHECK THE ROLE OF EXCEPTION USER
            var user = await _userManager.FindByNameAsync(username);

            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            IList<string> roles = await _userManager.GetRolesAsync(user);

            var zipName = string.Empty;

            bool blnRole = false;

            // 1. Define the files you want to include (e.g., from a database or file system)
            if (roles.Count > 1)
            {
                for (int ctr=0; ctr < roles.Count; ctr++)
                {
                    if (roles[ctr].ToString().Contains("EXRM_Processor") == true)
                    {
                        blnRole = true;
                    }
                }
            }
            else
            {
                if (roles[0].ToString().Contains("EXRM_Processor") == true)
                {
                    blnRole = true;
                }
            }
            if (blnRole == true)
            {
                var filesToZip = new List<string>
                    {
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/ExceptionProcessor.exe"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/EXRM_README.txt"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/CONFIG.txt"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/clsIonicZip.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/IonicZip.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCP.exe"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCP.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCPnet.dll")

                };

                zipName = $"Download-EXRMPro.zip";     //{DateTime.Now.ToString("yyyy-MM-dd")}.zip";

                // 2. Create a memory stream to hold the zip file data
                using (var memoryStream = new MemoryStream())
                {
                    // 3. Create a ZipArchive in create mode
                    using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                    {
                        // 4. Add each file to the zip archive
                        foreach (var file in filesToZip)
                        {
                            if (System.IO.File.Exists(file))
                            {
                                var entryName = Path.GetFileName(file); // Get just the file name
                                var entry = archive.CreateEntry(entryName, CompressionLevel.Fastest);

                                using (var entryStream = entry.Open())
                                using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                                {
                                    await fileStream.CopyToAsync(entryStream);
                                }
                            }
                        }
                    }
                    // 5. Reset the memory stream position to the beginning before returning
                    memoryStream.Seek(0, SeekOrigin.Begin);

                    ViewBag.Message = "Files downloaded successfully";

                    // 6. Return the file as a downloadable attachment
                    return File(
                        fileContents: memoryStream.ToArray(), // Convert to array for simple return
                        contentType: "application/zip",
                        fileDownloadName: zipName
                    );
                }
            }

            bool blnRole2 = false;

            if (roles.Count > 1)
            {
                for (int ctr = 0; ctr < roles.Count; ctr++)
                {
                    if (roles[ctr].ToString().Contains("EXRM_Consolidator") == true)
                    {
                        blnRole2 = true;
                    }
                }
            }
            else
            {
                if (roles[0].ToString().Contains("EXRM_Consolidator") == true)
                {
                    blnRole2 = true;
                }
            }
            
            if (blnRole2 == true)
            {
                var filesToZip = new List<string>
                    {
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/ExceptionConsolidator.exe"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/EXRM_README.txt"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/CONFIG.txt"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/clsIonicZip.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/IonicZip.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCP.exe"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCP.dll"),
                    Path.Combine(_hostingEnvironment.WebRootPath, "files/WinSCPnet.dll")
                };

                zipName = $"Download-EXRMCon.zip";     //{DateTime.Now.ToString("yyyy-MM-dd")}.zip";

                // 2. Create a memory stream to hold the zip file data
                using (var memoryStream = new MemoryStream())
                {
                    // 3. Create a ZipArchive in create mode
                    using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                    {
                        // 4. Add each file to the zip archive
                        foreach (var file in filesToZip)
                        {
                            if (System.IO.File.Exists(file))
                            {
                                var entryName = Path.GetFileName(file); // Get just the file name
                                var entry = archive.CreateEntry(entryName, CompressionLevel.Fastest);

                                using (var entryStream = entry.Open())
                                using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                                {
                                    await fileStream.CopyToAsync(entryStream);
                                }
                            }
                        }
                    }
                    // 5. Reset the memory stream position to the beginning before returning
                    memoryStream.Seek(0, SeekOrigin.Begin);

                    ViewBag.Message = "Files downloaded successfully";

                    // 6. Return the file as a downloadable attachment
                    return File(
                        fileContents: memoryStream.ToArray(), // Convert to array for simple return
                        contentType: "application/zip",
                        fileDownloadName: zipName
                    );
                }
            }
            return File(
                       fileContents: memoryStream2.ToArray(), // Convert to array for simple return
                       contentType: "application/zip",
                       fileDownloadName: zipName
                   );
        }
 
    }
}

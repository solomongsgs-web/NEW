﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO.Compression;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;
using System.Threading.Tasks;
using WinSCP;
using CTS_WEB.Services;
using CTS_WEB.Data;
using CTS_WEB.Models;
using CTS_WEB.Hubs;
using Microsoft.AspNetCore.Authorization;

namespace CTS_WEB.Controllers
{
    [Authorize(Roles = "MST_User,SuperAdmin")]
    public class MSTController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private readonly IHubContext<LongOperationHub> _hubContext;
        private readonly ILogger<MSTController> _logger;
        public MSTController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context, IHubContext<LongOperationHub> hubContext, ILogger<MSTController> logger)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
            _hubContext = hubContext;
            _logger = logger;
        }



        public IActionResult Index()
        {
            var viewModel = new FileListViewModel();
            string LocalDownloadPath = "mst_uploads";
            string OutputFilePath = "mst_splitted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // Get files from Folder 1
            if (Directory.Exists(folder1Path))
            {
                viewModel.Folder1Files = Directory.GetFiles(folder1Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder1Path);
                viewModel.Folder1Files = new List<SftpFileInfo>();
            }




            int sftpFilesCtr = viewModel.Folder1Files.Count;
            if (sftpFilesCtr > 0)
            {
                TempData["Message1"] = "There are " + sftpFilesCtr.ToString() + " MST file uploaded for splitting.";
            }

            // Get files from Folder 2
            if (Directory.Exists(folder2Path))
            {
                viewModel.Folder2Files = Directory.GetFiles(folder2Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
            int outFilesCtr = viewModel.Folder2Files.Count;
            if (outFilesCtr > 0)
            {
                TempData["Message2"] = outFilesCtr.ToString() + " file was splitted and generated MST files was zipped";
            }
            viewModel.LocalPath = folder1Path;
            viewModel.OutputPath = folder2Path;
            viewModel.EventDateTime = DateTime.Now;




            if (TempData["Message1"] != null)
            {
                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
            }
            if (TempData["Message2"] != null)
            {
                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
            }
            if (TempData["StatusMessage"] != null)
            {
                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
            }
            return View(viewModel);

        }
    }
}

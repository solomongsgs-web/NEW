﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO.Compression;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;
using System.Threading.Tasks;
using WinSCP;
using CTS_WEB.Services;
using CTS_WEB.Data;
using CTS_WEB.Models;
using CTS_WEB.Hubs;
using Microsoft.AspNetCore.Authorization;

namespace CTS_WEB.Controllers
{
    [Authorize(Roles = "DET_User,SuperAdmin")]
    public class DETController : Controller
    {
        int processFileCtr = 0;
        int generatedFileCtr = 0;
        bool blnDownload = false;
        string strWorkingFolder = string.Empty;
        public System.Data.DataTable tblBRANCH;
        public System.Data.DataTable tblDET;
        public System.Data.DataTable tblSORT;
        public string strNewFile;
        public string strOldFile;
        private string SOURCE_FOLDER;
        private string SOURCE_FILE;
        private string OUTPUT_FOLDER;
        private int LINECOUNT;
        public System.Data.DataTable SortedTable;

        private string NEW_FILE;

        private int PAGELINECOUNT;
        private int TOTALPAGE;
        private decimal decBRANCHAMOUNTTOTAL = 0;
        private decimal decPAGETOTAL = 0;
        private string[] Temp1 = new string[20000];
        private string[] Temp2 = new string[20000];
        private string[] Temp3 = new string[20000];
        private string[] Temp = new string[20000];
        private string[] Sort1 = new string[20000];
        private int iTOTALITEMS = 0;
        public double percentage = 0;
        public int totalFiles = 0;
   
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private readonly IHubContext<LongOperationHub> _hubContext;
        private readonly ILogger<DETController> _logger;
        public DETController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context, IHubContext<LongOperationHub> hubContext, ILogger<DETController> logger)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
            _hubContext = hubContext;
            _logger = logger;
        }

        

 

        public IActionResult Index()
        {
            var viewModel = new FileListViewModel();
            string LocalDownloadPath = "det_uploads";
            string OutputFilePath = "det_converted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // Get files from Folder 1
            if (Directory.Exists(folder1Path))
            {
                viewModel.Folder1Files = Directory.GetFiles(folder1Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder1Path);
                viewModel.Folder1Files = new List<SftpFileInfo>();
            }




            int sftpFilesCtr = viewModel.Folder1Files.Count;
            if (sftpFilesCtr > 0)
            {
                TempData["Message1"] = "There are " + sftpFilesCtr.ToString() + " DET MFT file uploaded for splitting.";
            }

            // Get files from Folder 2
            if (Directory.Exists(folder2Path))
            {
                viewModel.Folder2Files = Directory.GetFiles(folder2Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
            int outFilesCtr = viewModel.Folder2Files.Count;
            if (outFilesCtr > 0)
            {
                TempData["Message2"] = outFilesCtr.ToString() + " file was splitted and generated DET files was zipped";
            }
            viewModel.LocalPath = folder1Path;
            viewModel.OutputPath = folder2Path;
            viewModel.EventDateTime = DateTime.Now;




            if (TempData["Message1"] != null)
            {
                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
            }
            if (TempData["Message2"] != null)
            {
                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
            }
            if (TempData["StatusMessage"] != null)
            {
                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
            }
            return View(viewModel);
             
        }


        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ViewData["Message"] = "No file selected.";
                return View();
            }

            var folder1Path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "det_uploads");
            //Ensure the path exists 
            if (!Directory.Exists(folder1Path))
                Directory.CreateDirectory(Path.Combine(_hostingEnvironment.WebRootPath, "det_uploads"));



            // Specify the path where you want to save the file (e.g., in a "uploads" folder in wwwroot)
            var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "det_uploads", file.FileName);

            

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            //DELETE Existing ZIP Files
            var folder2Path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "det_converted");
            //Ensure the path exists 
            if (!Directory.Exists(folder2Path))
                Directory.CreateDirectory(Path.Combine(_hostingEnvironment.WebRootPath, "det_converted"));

            string[] filePaths = Directory.GetFiles(folder2Path);

            // Or another folder
            //string fullPath = Path.Combine(folderPath, fileName);
            int counter = filePaths.Length;
            for (int ctr = 0; ctr <= counter - 1; ctr++)
            {
                string sFileName = filePaths[ctr].ToString();
                if (System.IO.File.Exists(sFileName))
                {
                    System.IO.File.Delete(sFileName);
                }
            }

            //ViewData["Message"] = "File uploaded successfully to: " + path;
            return RedirectToAction("Index");
        }


       
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public string ConvMonth(string sDate)
        {
            string newDate = string.Empty;
            //20201210
            string strDD = sDate.Substring(6, 2).ToString();
            string strMM = sDate.Substring(4, 2).ToString();
            string strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            //newDate = newDate + " " + strDD + ", " + strYY;
            return newDate;

            //MAR 25, 2022
        }
        public string ConvDate(string sDate)
        {
            string newDate = string.Empty;
            //20201210
            string strDD = sDate.Substring(6, 2).ToString();
            string strMM = sDate.Substring(4, 2).ToString();
            string strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JAN";
                    break;
                case "02":
                    newDate = "FEB";
                    break;
                case "03":
                    newDate = "MAR";
                    break;
                case "04":
                    newDate = "APR";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUN";
                    break;
                case "07":
                    newDate = "JUL";
                    break;
                case "08":
                    newDate = "AUG";
                    break;
                case "09":
                    newDate = "SEP";
                    break;
                case "10":
                    newDate = "OCT";
                    break;
                case "11":
                    newDate = "NOV";
                    break;
                case "12":
                    newDate = "DEC";
                    break;
            }
            newDate = newDate + " " + strDD + ", " + strYY;
            return newDate;

            //MAR 25, 2022
        }

        public string GetDateMMDDYY(string strDate)
        {
            string strNewDate = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strNewDate = strMM + strDD + strYY;
            return strNewDate;
        }
        public string GetDateString(string strDate)
        {
            string strNewDate = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strNewDate = strYY + strMM + strDD;
            return strNewDate;
        }
        public string GetYear(string strDate)
        {
            string strYear = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            strYear = strYY;
            return strYear;
        }
        public string GetMonthFolder(string strDate)
        {
            string strMonth = string.Empty;
            string[] pdate = strDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            string sDate = strYY + strMM + strDD;
            string newDate = string.Empty;
            //20201210
            strDD = sDate.Substring(6, 2).ToString();
            strMM = sDate.Substring(4, 2).ToString();
            strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            return newDate;
        }

        //Download ZIP files
        [HttpGet]
        public IActionResult DownloadSelectedFiles(FileListViewModel model)
        {
            ViewBag.Message1 = "";
            ViewBag.Message2 = "";
            ViewBag.Message3 = "";
            var blnDownloadStatus = true;
            // Access selected files on RAW GEFU LISTS: model.Files.Where(f => f.IsSelected)
            var selectedFiles = model.Folder2Files.Where(f => f.IsSelected).ToList();
            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            for (int ctr = 0; ctr <= count - 1; ctr++)
            {
                // Handles the file download request
                if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                {
                    return BadRequest("File name is required.");
                }
                try
                {
                    string strFileName = selectedFiles[ctr].FileName.ToString();
                    var SourceFileFullPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted", strFileName);


                    if (!System.IO.File.Exists(SourceFileFullPath))
                    {
                        return NotFound();
                    }
                    else
                    { 
                        // Determine the MIME type (optional, "application/octet-stream" forces a download dialog)
                        // You can use a utility to get the correct MIME type based on file extension if needed.
                        var mimeType = "application/zip";

                        // Return the file using a FileStream
                        var fileStream = new FileStream(SourceFileFullPath, FileMode.Open);
                        blnDownload = true;


                        if (blnDownload == true)
                        {
                            string myDate = DateTime.Now.ToShortDateString();
                            string sDate = GetDateString(myDate);
                            string MonthFolder = ConvMonth(sDate);
                            string strDate = GetDateMMDDYY(myDate);
                            string strYY = GetYear(myDate).ToString();
                            MonthFolder = MonthFolder + " " + strYY;

                            string strWorkingFolder = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString();


                            //Clean and Delete Working Folder
                            if (Directory.Exists(strWorkingFolder))
                            {
                                Directory.Delete(strWorkingFolder, recursive: true);


                            }

                            if (TempData["Message1"] != null)
                            {
                                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
                            }
                            if (TempData["Message2"] == null)
                            {
                                TempData["Message2"] = count.ToString() + " file was downloaded";
                                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
                            }
                            if (TempData["StatusMessage"] != null)
                            {
                                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
                            }

                        }
                        // The third argument (fileName) forces the browser to download the file 
                        // with the specified name, rather than displaying it in the browser.
                        return File(fileStream, mimeType, strFileName);


                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., file not found, connection error)
                    return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                }

            }


            return RedirectToAction("Index");
        }

        public IActionResult Start(FileListViewModel model)
        {
            ViewBag.Message1 = "";
            ViewBag.Message2 = "";
            ViewBag.Message3 = "";

            var selectedFiles = model.Folder1Files.Where(f => f.IsSelected).ToList();
            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            string strFileName = string.Empty;
            if (count > 0)
            {
                strFileName = selectedFiles[count - 1].FileName.ToString();
                var SourceFileFullPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_uploads", strFileName);
                //MOVE FILES 
                string myDate = DateTime.Now.ToShortDateString();
                string MonthFolder = GetMonthFolder(myDate);
                string strYY = GetYear(myDate).ToString();
                MonthFolder = MonthFolder + " " + strYY;
                string strDate = GetDateMMDDYY(myDate);
                string strUploadPath = SourceFileFullPath;
                string strSourcePath = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString();
                string strSourceFile = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString() + "\\01008000.MTF";
                if (!System.IO.Directory.Exists(strSourceFile))
                {
                    System.IO.Directory.CreateDirectory(strSourcePath);
                    strWorkingFolder = strSourcePath;
                }
                else
                {
                    strWorkingFolder = strSourcePath;
                }
                strOldFile = strSourceFile;
                if (System.IO.File.Exists(strUploadPath))
                {
                    if (System.IO.File.Exists(strSourceFile))
                    {
                        System.IO.File.Delete(strSourceFile);
                        System.IO.File.Move(strUploadPath, strSourceFile);
                    }
                    else
                    {
                        //Move to Working Folder C-PCHC
                        System.IO.File.Move(strUploadPath, strSourceFile);
                    }
                }
                clsBranch Branch = new clsBranch();
               
                Double dblAmt = 0;
                Double dblTotal = 0;
                int intCount = 0;
                bool initPass = true;
                string strCount = string.Empty;
                string strAmount = string.Empty;
                string strTotal = string.Empty;
                string sDetail = string.Empty;
                string sBRDetail = string.Empty;
                string sOldDRBRCH = string.Empty;
                string sDRBRCH = string.Empty;

                myDate = DateTime.Now.ToShortDateString();
                string sDate = GetDateString(myDate);
                MonthFolder = Branch.ConvMonth(sDate);
                MonthFolder = MonthFolder + " " + strYY;

                strOldFile = strSourceFile;
                string strSourceNewPath = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString() + "\\01008000N.MTF";
                strNewFile = strSourceNewPath;
                SOURCE_FOLDER = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString();
                OUTPUT_FOLDER = "C:" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strDate.ToString();

                tblDET = Branch.CreateTableDET();
                tblSORT = Branch.CreateTableSORT();

                if (System.IO.File.Exists(strSourceFile) == true)
                {
                    int LCTR = Branch.ReadFileCountDetailLines(strSourceFile);
                    LINECOUNT = LCTR;
                    //Write to New File tblDET
                    //SORT tblDET by BRSTN
                    tblDET.DefaultView.Sort = "DRBRCH, ACCTNO, CHKNO ASC";
                    tblDET = tblDET.DefaultView.ToTable();

                    List<string> distinctValuesList = tblDET.AsEnumerable()
                                                            .Select(static row => row.Field<string>("DRBRCH"))
                                                            .Distinct()
                                                            .ToList();

                    totalFiles = distinctValuesList.Count;

                    if (tblDET.Rows.Count > 0)
                    {
                        //navigate to DataTable
                        //Write BF to DataTable
                        sBRDetail = Branch.GetBeginningOfFile(strSourceFile);
                        Branch.AddNewRowToDataTableBR(sBRDetail, tblSORT);

                        foreach (DataRow row in tblDET.Rows)
                        {
                            sDetail = row[0].ToString().Trim() + row[1].ToString().Trim() + row[2].ToString().Trim() + row[3].ToString().Trim() + row[4].ToString().Trim() + row[5].ToString().Trim() + row[6].ToString().Trim() + row[7].ToString().Trim() + row[8].ToString().Trim();
                            sDRBRCH = row[2].ToString().Trim();
                            strAmount = row[5].ToString().Trim();

                            if ((sDRBRCH != sOldDRBRCH) && (initPass == false))
                            {
                                //Write BR
                                strCount = intCount.ToString();
                                strTotal = dblTotal.ToString();
                                sBRDetail = "BR" + sOldDRBRCH + strCount.PadLeft(7, '0').Trim() + strTotal.PadLeft(14, '0');
                                sBRDetail = sBRDetail.PadRight(64, '0');
                                Branch.AddNewRowToDataTableBR(sBRDetail.Trim(), tblSORT);
                                //AddLineToNewFile(strNewFile, sBRDetail.Trim());
                                intCount = 0; //RESET
                                dblTotal = 0;
                                dblAmt = 0;
                                //ADD DETAIL 
                                Branch.AddNewRowToDataTable(row, tblSORT);
                                //AddLineToNewFile(strNewFile, sDetail.Trim());
                                dblAmt = Convert.ToDouble(strAmount);
                                dblTotal = dblTotal + dblAmt;
                                intCount = intCount + 1;
                                sOldDRBRCH = sDRBRCH;
                            }
                            else
                            {
                                //ADD DETAIL 
                                Branch.AddNewRowToDataTable(row, tblSORT);
                                //AddLineToNewFile(strNewFile, sDetail.Trim());
                                dblAmt = Convert.ToDouble(strAmount);
                                dblTotal = dblTotal + dblAmt;
                                intCount = intCount + 1;
                                sOldDRBRCH = sDRBRCH;
                                initPass = false;
                            }
                        }
                        //Write Last BR
                        strCount = intCount.ToString();
                        strTotal = dblTotal.ToString();
                        sBRDetail = "BR" + sOldDRBRCH + strCount.PadLeft(7, '0').Trim() + strTotal.PadLeft(14, '0');
                        sBRDetail = sBRDetail.PadRight(64, '0');
                        Branch.AddNewRowToDataTableBR(sBRDetail, tblSORT);
                    }
                }

                // Write the sorted data to the new text file using tab delimiter
                Branch.WriteDataTableToTextFile(tblSORT, strNewFile, "");

                System.IO.File.Delete(strSourceFile);
                System.IO.File.Move(strNewFile, strSourceFile);


           
            }

            return View();
        }
    }
}

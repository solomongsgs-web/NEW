﻿using Azure.Core;
using CTS_WEB.Controllers;
using CTS_WEB.Data;
using CTS_WEB.Models;
using CTS_WEB.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using Novell.Directory.Ldap;
using NuGet.Configuration;
using NuGet.Packaging.Signing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net.Mail;
using System.Security.Claims;
using System.Security.Cryptography;
using System.ServiceModel;
using System.Threading.Tasks;
 

namespace CTS_WEB.Areas.Identity.Pages.Account
{
    public class LoginModel : PageModel
    {
        public string currentUser;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ILogger<LoginModel> _logger;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SftpService _sftpService;
        private readonly IConfiguration _configuration;
        private readonly AppDBContext _context;
        private readonly object userpass;

        public LoginModel(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, ILogger<LoginModel> logger, SftpService sftpService, IConfiguration configuration, AppDBContext context)
        {
            _signInManager = signInManager;
            _logger = logger;
            _userManager = userManager;
            _sftpService = sftpService;
            _configuration = configuration;
            //_wcfClientService = wcfClientService;
            _context = context;
        }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        [BindProperty]
        public InputModel Input { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public IList<AuthenticationScheme> ExternalLogins { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public string ReturnUrl { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        [TempData]
        public string ErrorMessage { get; set; }

        /// <summary>
        ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
        ///     directly from your code. This API may change or be removed in future releases.
        /// </summary>
        public class InputModel
        {
            /// <summary>
            ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
            ///     directly from your code. This API may change or be removed in future releases.
            /// </summary>
            [Required]
            [Display(Name = "Email / Username")]
            //[EmailAddress]
            //public string Email { get; set; }
            public string InputField { get; set; }
            /// <summary>
            ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
            ///     directly from your code. This API may change or be removed in future releases.
            /// </summary>
            [Required]
            [DataType(DataType.Password)]
            public string Password { get; set; }

            /// <summary>
            ///     This API supports the ASP.NET Core Identity default UI infrastructure and is not intended to be used
            ///     directly from your code. This API may change or be removed in future releases.
            /// </summary>
            [Display(Name = "Remember me?")]
            public bool RememberMe { get; set; }
        }

        public async Task OnGetAsync(string returnUrl = null)
        {
            if (!string.IsNullOrEmpty(ErrorMessage))
            {
                ModelState.AddModelError(string.Empty, ErrorMessage);
            }

            returnUrl ??= Url.Content("~/");

            // Clear the existing external cookie to ensure a clean login process
            await HttpContext.SignOutAsync(IdentityConstants.ExternalScheme);

            ExternalLogins = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();

            ReturnUrl = returnUrl;
        }
        public bool IsValidEmail(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private bool UserLogin(string txtPassword, string txtUsername)
        {
            bool valid = false;

            try
            {
                //Specify Target domain
                var targetdomain = _sftpService.GetDomain();

                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, targetdomain, txtUsername, txtPassword))
                {
                    UserPrincipal user = UserPrincipal.FindByIdentity(pc, txtUsername);

                    if (user != null)
                    {
                        string FullName = user.Name;
                        if (!string.IsNullOrEmpty(txtPassword.Trim()) && !string.IsNullOrEmpty(txtUsername.Trim()))
                        {


                        }
                        valid = pc.ValidateCredentials(txtUsername.Trim(), txtPassword.Trim());
                        currentUser = txtUsername.Trim();

                        if (valid == true)
                        {

                            valid = true;

                        }
                        else
                        {
                            //Interaction.MsgBox("Invalid username/password.", MsgBoxStyle.Critical, "LDAP Login");

                            if (user.IsAccountLockedOut() == true)
                            {
                                //Interaction.MsgBox("Account is locked out. Please contact system administrator.", MsgBoxStyle.Critical, "LDAP Login");
                                valid = false;
                            }
                            valid = false;
                        }
                        return valid;
                    }
                    else
                    {
                        return valid;
                    }
                }         
                return valid;
            }
            catch (Exception ex)
            {
                //Interaction.MsgBox("Error connecting to AD. Please check connection.", MsgBoxStyle.Critical, "LDAP Login");
            }
            return valid;
        }

        public static string Decrypt1(byte[] cipherText, byte[] Key, byte[] IV)
        {
            string plaintext = null;
            // Create AesManaged    
#pragma warning disable SYSLIB0021 // Type or member is obsolete
            using (AesManaged aes = new AesManaged())
            {
                // Create a decryptor    
                ICryptoTransform decryptor = aes.CreateDecryptor(Key, IV);
                aes.Padding = PaddingMode.None;
                // Create the streams used for decryption.    
                using (MemoryStream ms = new MemoryStream(cipherText))
                {
                    // Create crypto stream    
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        // Read crypto stream    
                        using (StreamReader reader = new StreamReader(cs))
                            plaintext = reader.ReadToEnd();
                    }
                }
            }
#pragma warning restore SYSLIB0021 // Type or member is obsolete
            return plaintext;
        }

        public async Task<IActionResult> OnPostAsync(string returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");

            ExternalLogins = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();

            if (ModelState.IsValid)
            {
                var userName = "";
                if (IsValidEmail(Input.InputField))
                {
                    MailAddress address = new MailAddress(Input.InputField);
                    userName = address.User;

                    var user = await _userManager.FindByNameAsync(userName);
                    if (user != null)
                    {                    
                        //Get the Username
                        userName = user.UserName;
                    }
                }
                else
                {
                    userName = Input.InputField;
                }
                //initialized to false AD Authentication
                bool IsValid = false;

                if (userName == "superadmin")
                {
                    IsValid = true;
                }
                else
                {
                    IsValid = UserLogin(Input.Password, userName.Trim());
                }

                //Valid AD Account 
                if (IsValid == true)
                {
                    //Check if same password on CTS database
                    //Check if AD password supplied vs CTS Password is equal 
                    var user = await _userManager.FindByNameAsync(userName);

                    if (user != null)
                    {
                        bool blnSamePassword = await _userManager.CheckPasswordAsync(user, Input.Password);
                        //if same password 
                        if (blnSamePassword == true)
                        {
                            var result = await _signInManager.PasswordSignInAsync(userName, Input.Password, Input.RememberMe, lockoutOnFailure: false);
                            if (result.Succeeded)
                            {

                                _logger.LogInformation("User logged in.");
                                var isConnected = _sftpService.TestConnection();

                                if (isConnected)
                                {
                                    TempData["AlertMessage"] = "Connection Status: MFT Access Connected.";
                                    TempData["AlertType"] = "success";
                                }
                                else
                                {
                                    TempData["AlertMessage"] = "Connection Status: No Connection to MFT.";
                                    TempData["AlertType"] = "failed";
                                }

                                _logger.LogInformation("TestSftpConnection action executed. Connection status: {Status}", isConnected);

                                return LocalRedirect(returnUrl);


                            }
                            if (result.RequiresTwoFactor)
                            {
                                return RedirectToPage("./LoginWith2fa", new { ReturnUrl = returnUrl, RememberMe = Input.RememberMe });
                            }
                            if (result.IsLockedOut)
                            {
                                _logger.LogWarning("User account locked out.");
                                return RedirectToPage("./Lockout");
                            }
                            else
                            {
                                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                                return Page();
                            }
                        }
                        else
                        {
                            var settings = await _context.UserPass
                                   .FirstOrDefaultAsync(m => m.UserName == userName.Trim());

                            if (settings == null)
                            {
                                return NotFound();
                            }

                            //Change the password on CTS 
                            byte[] MyEnc = Convert.FromBase64String(settings.PASSWORD.Trim());
                            byte[] MyKey = Convert.FromBase64String(settings.PKEY.Trim());
                            byte[] MyIV = Convert.FromBase64String(settings.PIV.Trim());

                            string decryptedPass = Decrypt1(MyEnc, MyKey, MyIV);

                            if (Input.Password == decryptedPass)
                            {
                                //Do nothing
                            }
                            else
                            {
                                //Save New Password from AD to CTS
                                var user3 = await _userManager.ChangePasswordAsync(user, decryptedPass, Input.Password);
                            }
                            //var user2 = await _userManager.ResetPasswordAsync()
                        }
                    }
                }
                //NOT IN ACTIVE DIRECTORY 
                else
                {
                    _logger.LogInformation("User logged in failed. Credentials not in Active Directory.");
                    var isConnected2 = _sftpService.TestConnection();
                    if (isConnected2)
                    {
                        TempData["AlertMessage"] = "Connection Status: MFT Access Connected.";
                        TempData["AlertType"] = "success";
                    }
                    else
                    {
                        TempData["AlertMessage"] = "Connection Status: No Connection to MFT.";
                        TempData["AlertType"] = "failed";
                    }
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                    return Page();
                }
                  
            }

            // If we got this far, something failed, redisplay form
            return Page();
        }
    }
}
